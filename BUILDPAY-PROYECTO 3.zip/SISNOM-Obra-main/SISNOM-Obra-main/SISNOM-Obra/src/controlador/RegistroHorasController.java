package controlador;

import datos.RegistroHorasDAO;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import modelo.Obra;
import modelo.Persona;
import modelo.RegistroHoras;
import modelo.Rol;
import modelo.TipoActividad;

// PILAR EVIDENCIADO: Separación de responsabilidades (Arquitectura MVC)
public class RegistroHorasController {

    // La lista se carga de la base de datos al iniciar y se mantiene en memoria
    private List<RegistroHoras> listaRegistros;
    private ValidadorHorario validador;
    private ValidadorCompetencias validadorCompetencias;
    private RegistroHorasDAO registroDAO;

    /**
     * Recibe los otros controladores para poder buscar al trabajador, la obra
     * y a quien autorizó cada registro guardado en la base de datos.
     */
    public RegistroHorasController(PersonaController personaController, ObraController obraController) {
        this.listaRegistros = new ArrayList<>();
        this.validador = new ValidadorHorario();
        this.validadorCompetencias = new ValidadorCompetencias();
        this.registroDAO = new RegistroHorasDAO();

        // Cada fila trae: trabajador, obra, tipo de actividad, autorizado por, fecha, hora inicio, hora fin
        for (String[] fila : registroDAO.listar()) {
            Persona trabajador = personaController.buscarPorDocumento(fila[0]);
            Obra obra = obraController.buscarObra(fila[1]);
            Persona autorizadoPor = personaController.buscarPorDocumento(fila[3]);
            if (trabajador != null && obra != null && autorizadoPor != null) {
                listaRegistros.add(new RegistroHoras(trabajador, obra, TipoActividad.valueOf(fila[2]),
                        autorizadoPor, LocalDate.parse(fila[4]), LocalTime.parse(fila[5]), LocalTime.parse(fila[6])));
            }
        }
    }

    // --- Métodos para cumplir con el RF-03 y el RF-04 ---

    public boolean esHorarioValido(LocalTime horaInicio, LocalTime horaFin) {
        return validador.esHorarioValido(horaInicio, horaFin);
    }

    // Solo se pueden registrar horas en una actividad para la que la persona tiene habilidad
    public boolean puedeTrabajarEn(Persona trabajador, TipoActividad tipo) {
        return validadorCompetencias.tieneHabilidadRequerida(trabajador, tipo);
    }

    // Solo un maestro o un director de obra puede autorizar un turno
    public boolean puedeAutorizar(Persona persona) {
        return persona != null && persona.getRol() != Rol.OBRERO;
    }

    /**
     * Devuelve el registro que se cruza con el nuevo, o null si no hay cruce.
     * Solo se compara contra los registros del mismo trabajador.
     */
    public RegistroHoras buscarConflicto(RegistroHoras nuevoRegistro) {
        List<RegistroHoras> historial = obtenerHistorial(nuevoRegistro.getTrabajador());
        return validador.obtenerRegistroEnConflicto(nuevoRegistro, historial);
    }

    public boolean registrarHoras(RegistroHoras nuevoRegistro) {
        if (!esHorarioValido(nuevoRegistro.getHoraInicio(), nuevoRegistro.getHoraFin())) {
            return false;
        }
        if (!puedeTrabajarEn(nuevoRegistro.getTrabajador(), nuevoRegistro.getTipoActividad())
                || !puedeAutorizar(nuevoRegistro.getAutorizadoPor())) {
            return false;
        }
        List<RegistroHoras> historial = obtenerHistorial(nuevoRegistro.getTrabajador());
        if (validador.existeCruceHorario(nuevoRegistro, historial)) {
            return false; // RF-04: se bloquea el guardado
        }
        listaRegistros.add(nuevoRegistro);
        registroDAO.guardar(nuevoRegistro);
        return true;
    }

    public List<RegistroHoras> obtenerHistorial(Persona trabajador) {
        List<RegistroHoras> historial = new ArrayList<>();
        for (RegistroHoras registro : listaRegistros) {
            if (registro.getTrabajador() == trabajador) {
                historial.add(registro);
            }
        }
        return historial;
    }

    /**
     * Devuelve los registros de la persona entre las dos fechas (incluidas).
     * Es lo que necesita la nómina (RF-07): cada registro trae sus horas y su tarifa.
     */
    public List<RegistroHoras> obtenerRegistrosEnPeriodo(Persona trabajador, LocalDate inicio, LocalDate fin) {
        List<RegistroHoras> resultado = new ArrayList<>();
        for (RegistroHoras registro : obtenerHistorial(trabajador)) {
            LocalDate fecha = registro.getFecha();
            if (!fecha.isBefore(inicio) && !fecha.isAfter(fin)) {
                resultado.add(registro);
            }
        }
        return resultado;
    }

    public List<RegistroHoras> obtenerTodosLosRegistros() {
        return listaRegistros;
    }
}
