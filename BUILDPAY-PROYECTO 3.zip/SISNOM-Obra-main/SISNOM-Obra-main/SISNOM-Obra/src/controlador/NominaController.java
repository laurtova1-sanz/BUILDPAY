package controlador;

import datos.NominaDAO;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import modelo.CalculadoraPago;
import modelo.Inasistencia;
import modelo.Nomina;
import modelo.PagoPorHora;
import modelo.Persona;
import modelo.Prestamo;
import modelo.RegistroHoras;

public class NominaController {

    // La lista se carga de la base de datos al iniciar y se mantiene en memoria
    private List<Nomina> historialNominas;
    // PILAR EVIDENCIADO: Polimorfismo (Inyectamos la interfaz, no la clase concreta directamente)
    private CalculadoraPago calculadora;
    private NominaDAO nominaDAO;
    private PrestamoController prestamoController;

    /**
     * Recibe el controlador de personal para buscar a la persona de cada nómina guardada,
     * y el de préstamos para guardar el saldo nuevo después de un descuento.
     */
    public NominaController(PersonaController personaController, PrestamoController prestamoController) {
        this.historialNominas = new ArrayList<>();
        // Instanciamos el comportamiento de pago por hora
        this.calculadora = new PagoPorHora();
        this.nominaDAO = new NominaDAO();
        this.prestamoController = prestamoController;

        // Cada fila trae: persona, inicio, fin, horas, bruto, desc. inasistencias, desc. préstamo, neto
        for (String[] fila : nominaDAO.listar()) {
            Persona persona = personaController.buscarPorDocumento(fila[0]);
            if (persona != null) {
                historialNominas.add(new Nomina(persona, LocalDate.parse(fila[1]), LocalDate.parse(fila[2]),
                        Double.parseDouble(fila[3]), Double.parseDouble(fila[4]),
                        Double.parseDouble(fila[5]), Double.parseDouble(fila[6]),
                        Double.parseDouble(fila[7])));
            }
        }
    }

    /**
     * RF-07: Generación de nómina calculando horas, inasistencias y préstamos.
     * Sirve igual para obreros y directores de obra, porque recibe una Persona.
     * Cada registro de horas se paga con la tarifa de la actividad que se hizo.
     */
    public Nomina generarNomina(Persona persona, LocalDate inicio, LocalDate fin,
                                List<RegistroHoras> registrosDelPeriodo,
                                List<Inasistencia> inasistencias,
                                Prestamo prestamoActivo) {

        // 1. Calcular pago base usando polimorfismo, registro por registro
        double horasTrabajadas = 0;
        double pagoBruto = 0;
        for (RegistroHoras registro : registrosDelPeriodo) {
            horasTrabajadas += registro.calcularHoras();
            pagoBruto += calculadora.calcularPago(registro.calcularHoras(), registro.getTarifaAplicada());
        }

        // 2. Calcular descuento por inasistencias (se descuentan 8 horas por cada falta,
        //    con la tarifa general de la persona, que es la más baja de sus habilidades)
        double descuentoInasistencias = 0;
        if (inasistencias != null) {
            descuentoInasistencias = inasistencias.size() * (8 * persona.getTarifaPorHora());
        }

        // 3. Calcular abono a préstamo (se descuenta el 10% del salario bruto o el saldo total si es menor)
        double descuentoPrestamo = 0;
        if (prestamoActivo != null && prestamoActivo.getSaldoPendiente() > 0) {
            double abonoSugerido = pagoBruto * 0.10;
            descuentoPrestamo = Math.min(abonoSugerido, prestamoActivo.getSaldoPendiente());
            prestamoActivo.aplicarDescuento(descuentoPrestamo); // Actualiza el saldo en la clase Prestamo
            prestamoController.guardarSaldos(); // y también en la base de datos
        }

        // 4. Calcular el pago neto
        double pagoNeto = pagoBruto - descuentoInasistencias - descuentoPrestamo;

        // Si las deudas superan el sueldo, el neto no puede ser negativo
        if (pagoNeto < 0) pagoNeto = 0;

        // 5. Crear el registro de nómina
        Nomina nuevaNomina = new Nomina(persona, inicio, fin, horasTrabajadas, pagoBruto,
                descuentoInasistencias, descuentoPrestamo, pagoNeto);
        historialNominas.add(nuevaNomina);
        nominaDAO.guardar(nuevaNomina);

        return nuevaNomina;
    }

    /**
     * Indica si la persona ya tiene una nómina cuyo periodo se cruza con las fechas dadas.
     * Sirve para no pagar dos veces el mismo periodo ni descontar el préstamo dos veces.
     */
    public boolean existeNominaEnPeriodo(Persona persona, LocalDate inicio, LocalDate fin) {
        for (Nomina nomina : historialNominas) {
            boolean periodoCruzado = !inicio.isAfter(nomina.getFechaFinPeriodo())
                    && !fin.isBefore(nomina.getFechaInicioPeriodo());
            if (nomina.getPersona() == persona && periodoCruzado) {
                return true;
            }
        }
        return false;
    }

    // RF-08: Retorna la lista para que la Vista la dibuje en el JTable
    public List<Nomina> obtenerNominasGeneradas() {
        return historialNominas;
    }
}
