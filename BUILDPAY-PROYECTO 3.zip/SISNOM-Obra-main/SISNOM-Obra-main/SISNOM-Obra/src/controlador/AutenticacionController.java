package controlador;

import modelo.Rol;

// PILAR EVIDENCIADO: Separación de responsabilidades (Arquitectura MVC)
public class AutenticacionController {

    // Usuarios fijos para la prueba. No se guardan en la base de datos.
    private static final String USUARIO_MAESTRO = "maestro";
    private static final String CLAVE_MAESTRO = "maestro123";
    private static final String USUARIO_DIRECTOR = "director";
    private static final String CLAVE_DIRECTOR = "director123";

    /**
     * Devuelve el rol del usuario si los datos son correctos,
     * o null si el usuario o la contraseña no coinciden.
     */
    public Rol iniciarSesion(String usuario, String clave) {
        if (USUARIO_MAESTRO.equals(usuario) && CLAVE_MAESTRO.equals(clave)) {
            return Rol.MAESTRO;
        }
        if (USUARIO_DIRECTOR.equals(usuario) && CLAVE_DIRECTOR.equals(clave)) {
            return Rol.DIRECTOR_OBRA;
        }
        return null;
    }
}