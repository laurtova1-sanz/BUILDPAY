package controlador;

import java.util.List;
import modelo.Habilidad;
import modelo.Persona;
import modelo.TipoActividad;

// PILAR EVIDENCIADO: Separación de responsabilidades (Arquitectura MVC)
// Mismo patrón que ValidadorHorario: solo decide si una asignación es válida,
// no guarda nada. Lo usan ObraController y RegistroHorasController.
public class ValidadorCompetencias {

    /**
     * La persona solo puede hacer una actividad si tiene esa habilidad.
     * Si devuelve false, la asignación se bloquea.
     */
    public boolean tieneHabilidadRequerida(Persona persona, TipoActividad tipoRequerido) {
        return persona != null && persona.tieneHabilidad(tipoRequerido);
    }

    /**
     * La persona está sobrecalificada si tiene alguna habilidad especializada
     * (que no sea BASICO) distinta de la que pide la actividad.
     * Ejemplo: un electricista certificado asignado a una actividad BASICO.
     */
    public boolean estaSobrecalificado(Persona persona, TipoActividad tipoRequerido) {
        for (Habilidad habilidad : persona.getHabilidades()) {
            TipoActividad tipo = habilidad.getTipoActividad();
            if (tipo != tipoRequerido && tipo != TipoActividad.BASICO) {
                return true;
            }
        }
        return false;
    }

    /**
     * Busca entre los candidatos a alguien que también tenga la habilidad requerida
     * y cobre menos por hora en ella. Devuelve la opción más barata, o null si la
     * persona elegida ya es la más económica.
     */
    public Persona buscarAlternativaMasEconomica(Persona elegida, TipoActividad tipoRequerido,
                                                 List<Persona> candidatos) {
        double tarifaElegida = elegida.obtenerHabilidad(tipoRequerido).getTarifaPorHora();
        Persona masBarata = null;
        double tarifaMasBarata = tarifaElegida;

        for (Persona candidato : candidatos) {
            if (candidato != elegida && candidato.tieneHabilidad(tipoRequerido)) {
                double tarifa = candidato.obtenerHabilidad(tipoRequerido).getTarifaPorHora();
                if (tarifa < tarifaMasBarata) {
                    masBarata = candidato;
                    tarifaMasBarata = tarifa;
                }
            }
        }
        return masBarata;
    }

    /**
     * Devuelve el texto de advertencia si la persona está sobrecalificada y además
     * hay alguien más económico que puede hacer la actividad. Devuelve null si no hay nada que advertir.
     * La advertencia no bloquea: el usuario decide si asigna de todas formas.
     */
    public String obtenerAdvertencia(Persona elegida, TipoActividad tipoRequerido, List<Persona> candidatos) {
        if (!estaSobrecalificado(elegida, tipoRequerido)) {
            return null;
        }
        Persona alternativa = buscarAlternativaMasEconomica(elegida, tipoRequerido, candidatos);
        if (alternativa == null) {
            return null;
        }
        double tarifaElegida = elegida.obtenerHabilidad(tipoRequerido).getTarifaPorHora();
        double tarifaAlternativa = alternativa.obtenerHabilidad(tipoRequerido).getTarifaPorHora();
        return elegida.getNombre() + " está sobrecalificado para esta actividad ("
                + tipoRequerido.getEtiqueta() + ") y cobra $" + (long) tarifaElegida + " por hora.\n"
                + alternativa.getNombre() + " también puede hacerla y cobra $" + (long) tarifaAlternativa + " por hora.";
    }
}
