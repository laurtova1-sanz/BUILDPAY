package controlador;

import datos.ObraDAO;
import java.util.ArrayList;
import java.util.List;
import modelo.ActividadSemanal;
import modelo.Obra;
import modelo.Persona;
import modelo.TipoActividad;

public class ObraController {

    // La lista se carga de la base de datos al iniciar y se mantiene en memoria
    private List<Obra> listaObras;
    private ObraDAO obraDAO;
    private ValidadorCompetencias validador;

    /**
     * Recibe el controlador de personal para poder buscar, por su documento,
     * a las personas asignadas a cada obra y a cada actividad.
     */
    public ObraController(PersonaController personaController) {
        this.obraDAO = new ObraDAO();
        this.validador = new ValidadorCompetencias();
        this.listaObras = obraDAO.listar();

        // Cada fila trae: obra, persona
        for (String[] fila : obraDAO.listarPersonalAsignado()) {
            Obra obra = buscarObra(fila[0]);
            Persona persona = personaController.buscarPorDocumento(fila[1]);
            if (obra != null && persona != null) {
                obra.asignarPersona(persona);
            }
        }
        // Cada fila trae: obra, semana, nombre, tipo
        for (String[] fila : obraDAO.listarActividades()) {
            Obra obra = buscarObra(fila[0]);
            if (obra != null) {
                obra.agregarActividad(new ActividadSemanal(obra, Integer.parseInt(fila[1]), fila[2],
                        TipoActividad.valueOf(fila[3])));
            }
        }
        // Cada fila trae: obra, semana, actividad, persona
        for (String[] fila : obraDAO.listarPersonalDeActividades()) {
            ActividadSemanal actividad = buscarActividad(buscarObra(fila[0]), Integer.parseInt(fila[1]), fila[2]);
            Persona persona = personaController.buscarPorDocumento(fila[3]);
            if (actividad != null && persona != null) {
                actividad.asignarPersona(persona);
            }
        }
    }

    // --- Métodos para cumplir con el RF-02 ---

    public boolean registrarObra(Obra obra) {
        if (obra == null || obra.getNombre().isEmpty() || obra.getUbicacion().isEmpty()
                || obra.getNumeroPisos() < 1 || obra.getAlturaMetros() < 0) {
            return false;
        }
        // No puede haber dos obras con el mismo nombre
        if (existeObra(obra.getNombre())) {
            return false;
        }
        listaObras.add(obra);
        obraDAO.guardar(obra);
        return true;
    }

    public boolean existeObra(String nombre) {
        return buscarObra(nombre) != null;
    }

    // Devuelve la obra con ese nombre, o null si no existe
    public Obra buscarObra(String nombre) {
        for (Obra obra : listaObras) {
            if (obra.getNombre().equalsIgnoreCase(nombre)) {
                return obra;
            }
        }
        return null;
    }

    // Devuelve false si falta algún dato o si la persona ya estaba asignada a esa obra
    public boolean asignarPersonaAObra(Obra obra, Persona persona) {
        if (obra != null && persona != null && obra.asignarPersona(persona)) {
            obraDAO.guardarPersonaAsignada(obra.getNombre(), persona.getDocumentoIdentidad());
            return true;
        }
        return false;
    }

    // --- Cronograma semanal ---

    // Devuelve false si faltan datos o si esa obra ya tiene una actividad con ese nombre en esa semana
    public boolean registrarActividad(Obra obra, int semana, String nombre, TipoActividad tipoRequerido) {
        if (obra == null || semana < 1 || nombre.isEmpty() || tipoRequerido == null) {
            return false;
        }
        if (buscarActividad(obra, semana, nombre) != null) {
            return false;
        }
        ActividadSemanal actividad = new ActividadSemanal(obra, semana, nombre, tipoRequerido);
        obra.agregarActividad(actividad);
        obraDAO.guardarActividad(actividad);
        return true;
    }

    // Devuelve la actividad de esa obra con esa semana y ese nombre, o null si no existe
    public ActividadSemanal buscarActividad(Obra obra, int semana, String nombre) {
        if (obra == null) {
            return null;
        }
        for (ActividadSemanal actividad : obra.getActividades()) {
            if (actividad.getSemana() == semana && actividad.getNombre().equalsIgnoreCase(nombre)) {
                return actividad;
            }
        }
        return null;
    }

    // --- Validación de competencias antes de asignar personal a una actividad ---

    public boolean puedeHacerActividad(Persona persona, ActividadSemanal actividad) {
        return validador.tieneHabilidadRequerida(persona, actividad.getTipoRequerido());
    }

    /**
     * Devuelve la advertencia si la persona está sobrecalificada y hay alguien
     * más económico en la misma obra, o null si no hay nada que advertir.
     */
    public String obtenerAdvertenciaCompetencia(Persona persona, ActividadSemanal actividad) {
        return validador.obtenerAdvertencia(persona, actividad.getTipoRequerido(),
                actividad.getObra().getPersonalAsignado());
    }

    /**
     * Asigna la persona a la actividad. Se bloquea (devuelve false) si no tiene
     * la habilidad requerida o si ya estaba asignada.
     * Si la persona no estaba asignada a la obra, también se asigna a la obra.
     */
    public boolean asignarPersonaAActividad(ActividadSemanal actividad, Persona persona) {
        if (actividad == null || persona == null || !puedeHacerActividad(persona, actividad)) {
            return false;
        }
        if (!actividad.asignarPersona(persona)) {
            return false;
        }
        obraDAO.guardarPersonaEnActividad(actividad, persona.getDocumentoIdentidad());
        asignarPersonaAObra(actividad.getObra(), persona);
        return true;
    }

    public List<Obra> obtenerTodasLasObras() {
        return listaObras;
    }

    // Todas las actividades de todas las obras, para la tabla del cronograma
    public List<ActividadSemanal> obtenerTodasLasActividades() {
        List<ActividadSemanal> actividades = new ArrayList<>();
        for (Obra obra : listaObras) {
            actividades.addAll(obra.getActividades());
        }
        return actividades;
    }
}
