package controlador;

import datos.InasistenciaDAO;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import modelo.Inasistencia;
import modelo.Persona;

// PILAR EVIDENCIADO: Separación de responsabilidades (Arquitectura MVC)
public class InasistenciaController {

    // La lista se carga de la base de datos al iniciar y se mantiene en memoria
    private List<Inasistencia> listaInasistencias;
    private InasistenciaDAO inasistenciaDAO;

    // Recibe el controlador de personal para buscar a la persona de cada inasistencia guardada
    public InasistenciaController(PersonaController personaController) {
        this.listaInasistencias = new ArrayList<>();
        this.inasistenciaDAO = new InasistenciaDAO();

        // Cada fila trae: persona, fecha, motivo
        for (String[] fila : inasistenciaDAO.listar()) {
            Persona persona = personaController.buscarPorDocumento(fila[0]);
            if (persona != null) {
                listaInasistencias.add(new Inasistencia(persona, LocalDate.parse(fila[1]), fila[2]));
            }
        }
    }

    public boolean existeInasistencia(Persona persona, LocalDate fecha) {
        for (Inasistencia inasistencia : listaInasistencias) {
            if (inasistencia.getPersona() == persona && inasistencia.getFecha().equals(fecha)) {
                return true;
            }
        }
        return false;
    }

    public boolean registrarInasistencia(Persona persona, LocalDate fecha, String motivo) {
        // Una misma falta no se registra dos veces (se descontaría doble en la nómina)
        if (persona == null || fecha == null || existeInasistencia(persona, fecha)) {
            return false;
        }
        Inasistencia nueva;
        if (motivo == null || motivo.isEmpty()) {
            // El modelo pone "Sin justificar" cuando no se indica el motivo
            nueva = new Inasistencia(persona, fecha);
        } else {
            nueva = new Inasistencia(persona, fecha, motivo);
        }
        listaInasistencias.add(nueva);
        inasistenciaDAO.guardar(nueva);
        return true;
    }

    /**
     * Devuelve las inasistencias de la persona entre las dos fechas (incluidas).
     * Es la lista que necesita la nómina (RF-07).
     */
    public List<Inasistencia> obtenerInasistenciasEnPeriodo(Persona persona, LocalDate inicio, LocalDate fin) {
        List<Inasistencia> resultado = new ArrayList<>();
        for (Inasistencia inasistencia : listaInasistencias) {
            LocalDate fecha = inasistencia.getFecha();
            if (inasistencia.getPersona() == persona && !fecha.isBefore(inicio) && !fecha.isAfter(fin)) {
                resultado.add(inasistencia);
            }
        }
        return resultado;
    }

    public List<Inasistencia> obtenerTodasLasInasistencias() {
        return listaInasistencias;
    }
}
