package controlador;

import datos.PrestamoDAO;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import modelo.Persona;
import modelo.Prestamo;

// PILAR EVIDENCIADO: Separación de responsabilidades (Arquitectura MVC)
public class PrestamoController {

    // La lista se carga de la base de datos al iniciar y se mantiene en memoria
    private List<Prestamo> listaPrestamos;
    private PrestamoDAO prestamoDAO;

    // Recibe el controlador de personal para buscar a la persona de cada préstamo guardado
    public PrestamoController(PersonaController personaController) {
        this.listaPrestamos = new ArrayList<>();
        this.prestamoDAO = new PrestamoDAO();

        // Cada fila trae: persona, monto inicial, saldo pendiente, fecha
        for (String[] fila : prestamoDAO.listar()) {
            Persona persona = personaController.buscarPorDocumento(fila[0]);
            if (persona != null) {
                Prestamo prestamo = new Prestamo(persona, Double.parseDouble(fila[1]), LocalDate.parse(fila[3]));
                prestamo.setSaldoPendiente(Double.parseDouble(fila[2]));
                listaPrestamos.add(prestamo);
            }
        }
    }

    public boolean registrarPrestamo(Persona persona, double monto, LocalDate fecha) {
        if (persona == null || fecha == null || monto <= 0) {
            return false;
        }
        Prestamo nuevo = new Prestamo(persona, monto, fecha);
        listaPrestamos.add(nuevo);
        prestamoDAO.guardar(nuevo);
        return true;
    }

    /**
     * Devuelve el primer préstamo de la persona que todavía tiene saldo pendiente,
     * o null si no debe nada. Es el préstamo que se descuenta en la nómina (RF-07).
     */
    public Prestamo obtenerPrestamoActivo(Persona persona) {
        for (Prestamo prestamo : listaPrestamos) {
            if (prestamo.getPersona() == persona && prestamo.getSaldoPendiente() > 0) {
                return prestamo;
            }
        }
        return null;
    }

    // Guarda en la base de datos los saldos actuales. Se llama después de generar una nómina.
    public void guardarSaldos() {
        prestamoDAO.actualizarTodos(listaPrestamos);
    }

    public List<Prestamo> obtenerTodosLosPrestamos() {
        return listaPrestamos;
    }
}
