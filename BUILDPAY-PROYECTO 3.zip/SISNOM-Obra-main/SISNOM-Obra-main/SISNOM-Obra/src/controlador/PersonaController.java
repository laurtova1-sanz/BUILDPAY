package controlador;

import datos.PersonaDAO;
import java.util.ArrayList;
import java.util.List;
import modelo.Habilidad;
import modelo.Persona;
import modelo.Rol;
import modelo.TipoActividad;

// PILAR EVIDENCIADO: Separación de responsabilidades (Arquitectura MVC)
// Reemplaza al antiguo ObreroController: ahora obreros y directores de obra
// están en una sola lista de Persona, porque tienen los mismos datos.
public class PersonaController {

    // La lista se carga de la base de datos al iniciar y se mantiene en memoria
    // PILAR EVIDENCIADO: Polimorfismo (la lista de Persona guarda Obrero y DirectorObra)
    private List<Persona> listaPersonal;
    private PersonaDAO personaDAO;

    public PersonaController() {
        this.personaDAO = new PersonaDAO();
        this.listaPersonal = personaDAO.listar();
    }

    // --- Métodos para cumplir con el RF-01 ---

    public boolean registrarPersona(Persona persona) {
        // Validar que los datos obligatorios no vengan vacíos
        if (persona == null || persona.getNombre().isEmpty() || persona.getDocumentoIdentidad().isEmpty()) {
            return false;
        }
        // No puede haber dos personas con el mismo documento
        if (existeDocumento(persona.getDocumentoIdentidad())) {
            return false;
        }
        listaPersonal.add(persona);
        personaDAO.guardar(persona);
        return true; // Registro exitoso
    }

    public boolean existeDocumento(String documento) {
        return buscarPorDocumento(documento) != null;
    }

    // Devuelve la persona con ese documento, o null si no existe
    public Persona buscarPorDocumento(String documento) {
        for (Persona persona : listaPersonal) {
            if (persona.getDocumentoIdentidad().equals(documento)) {
                return persona;
            }
        }
        return null;
    }

    // --- Habilidades ---

    // Agrega la habilidad o, si ya la tenía, actualiza su tarifa
    public boolean agregarHabilidad(Persona persona, TipoActividad tipo, double tarifa) {
        if (persona == null || tipo == null || tarifa <= 0) {
            return false;
        }
        persona.agregarHabilidad(new Habilidad(tipo, tarifa));
        personaDAO.actualizarHabilidades(persona);
        return true;
    }

    public boolean quitarHabilidad(Persona persona, TipoActividad tipo) {
        if (persona == null || !persona.tieneHabilidad(tipo)) {
            return false;
        }
        persona.quitarHabilidad(tipo);
        personaDAO.actualizarHabilidades(persona);
        return true;
    }

    // Métodos para que la vista (las tablas y combos) puedan consultar los datos
    public List<Persona> obtenerTodoElPersonal() {
        return listaPersonal;
    }

    // Maestros y directores de obra: son los que pueden autorizar turnos
    public List<Persona> obtenerSupervisores() {
        List<Persona> supervisores = new ArrayList<>();
        for (Persona persona : listaPersonal) {
            if (persona.getRol() != Rol.OBRERO) {
                supervisores.add(persona);
            }
        }
        return supervisores;
    }
}
