package modelo;

// PILAR EVIDENCIADO: Encapsulamiento (Agrupa los datos del contacto de emergencia)
// La usa Persona para saber a quién llamar si hay un accidente en la obra (composición).
public class ContactoEmergencia {

    private String nombre;
    private String parentesco;
    private String telefono;

    public ContactoEmergencia(String nombre, String parentesco, String telefono) {
        this.nombre = nombre;
        this.parentesco = parentesco;
        this.telefono = telefono;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
