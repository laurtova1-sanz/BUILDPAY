package modelo;

// PILAR EVIDENCIADO: Herencia (Uso de 'extends' para heredar de Persona)
// Reemplaza al antiguo Capataz. Tiene exactamente los mismos datos que el Obrero;
// su tarifa normalmente es la de la habilidad SUPERVISION.
// Empieza con el rol DIRECTOR_OBRA; con setRol se puede cambiar a MAESTRO.
public class DirectorObra extends Persona {

    public DirectorObra(String nombre, String tipoDocumento, String documentoIdentidad) {
        // Uso de 'super' para invocar el constructor de la clase padre
        super(nombre, tipoDocumento, documentoIdentidad, Rol.DIRECTOR_OBRA);
    }
}
