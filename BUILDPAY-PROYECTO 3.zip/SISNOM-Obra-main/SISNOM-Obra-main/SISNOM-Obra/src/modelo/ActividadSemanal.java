package modelo;

import java.util.ArrayList;
import java.util.List;

// PILAR EVIDENCIADO: Encapsulamiento
// Una tarea del cronograma semanal de una obra. Ejemplo: semana 3, "Instalar tomas", ELECTRICIDAD.
public class ActividadSemanal {

    private Obra obra;
    private int semana;
    private String nombre;
    // Habilidad que debe tener quien se asigne a esta actividad
    private TipoActividad tipoRequerido;
    private List<Persona> personalAsignado;

    public ActividadSemanal(Obra obra, int semana, String nombre, TipoActividad tipoRequerido) {
        this.obra = obra;
        this.semana = semana;
        this.nombre = nombre;
        this.tipoRequerido = tipoRequerido;
        this.personalAsignado = new ArrayList<>();
    }

    // Agrega a la persona si todavía no estaba. Devuelve false si ya estaba asignada.
    // Antes de llamarlo, el controlador revisa la habilidad con ValidadorCompetencias.
    public boolean asignarPersona(Persona persona) {
        if (personalAsignado.contains(persona)) {
            return false;
        }
        personalAsignado.add(persona);
        return true;
    }

    // Getters y Setters
    public Obra getObra() {
        return obra;
    }

    public void setObra(Obra obra) {
        this.obra = obra;
    }

    public int getSemana() {
        return semana;
    }

    public void setSemana(int semana) {
        this.semana = semana;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TipoActividad getTipoRequerido() {
        return tipoRequerido;
    }

    public void setTipoRequerido(TipoActividad tipoRequerido) {
        this.tipoRequerido = tipoRequerido;
    }

    public List<Persona> getPersonalAsignado() {
        return personalAsignado;
    }

    // Texto con el que aparece en las listas desplegables, por ejemplo "Casa Norte - Semana 3: Instalar tomas"
    @Override
    public String toString() {
        return obra.getNombre() + " - Semana " + semana + ": " + nombre;
    }
}
