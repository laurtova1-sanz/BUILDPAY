package modelo;

// Nivel de cada persona dentro de la obra.
// El MAESTRO y el DIRECTOR_OBRA pueden entrar al sistema; el OBRERO no tiene usuario.
// El rol es independiente de los datos: todos tienen los mismos datos en Persona.
public enum Rol {
    DIRECTOR_OBRA("Director de obra"),
    MAESTRO("Maestro"),
    OBRERO("Obrero");

    private final String etiqueta;

    Rol(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    // Texto con el que aparece en las listas desplegables de la vista
    @Override
    public String toString() {
        return etiqueta;
    }
}
