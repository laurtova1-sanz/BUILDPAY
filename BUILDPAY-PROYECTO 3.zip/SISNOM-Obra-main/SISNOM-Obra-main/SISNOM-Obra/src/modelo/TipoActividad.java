package modelo;

// Tipos de actividad que se hacen en una obra.
// Sirven para dos cosas: decir qué sabe hacer una persona (Habilidad)
// y qué se necesita para una tarea del cronograma (ActividadSemanal).
public enum TipoActividad {
    BASICO("Básico"),
    ALTURAS("Trabajo en alturas"),
    ELECTRICIDAD("Electricidad"),
    BALDOSAS("Baldosas"),
    ESPACIOS_CONFINADOS("Espacios confinados"),
    // Existe para que el director de obra o el maestro también tengan
    // una tarifa por hora y se les pueda calcular la nómina
    SUPERVISION("Supervisión");

    private final String etiqueta;

    TipoActividad(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    // Texto con el que aparece en las listas desplegables de la vista
    @Override
    public String toString() {
        return etiqueta;
    }
}
