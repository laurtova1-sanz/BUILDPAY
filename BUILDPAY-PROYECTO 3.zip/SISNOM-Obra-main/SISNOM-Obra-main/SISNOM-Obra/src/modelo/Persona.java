package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

// PILAR EVIDENCIADO: Abstracción (Clase abstracta que define el molde general)
// Aquí viven TODOS los datos del trabajador. Obrero y DirectorObra los heredan
// sin agregar nada, porque a los dos se les legaliza el empleo y se les paga nómina.
public abstract class Persona {

    // PILAR EVIDENCIADO: Encapsulamiento (Atributos privados)

    // --- Identificación ---
    private String nombre;
    private String tipoDocumento; // CC, CE, PPT, TI...
    private String documentoIdentidad;
    private LocalDate fechaNacimiento;
    private String genero;
    private String direccion;
    private String telefono;

    // --- Vinculación laboral ---
    private Rol rol;
    private LocalDate fechaIngreso;
    private TipoVinculacion tipoVinculacion;

    // --- Datos agrupados en otras clases (composición: la persona TIENE estos datos) ---
    private DatosSeguridadSocial seguridadSocial;
    private ContactoEmergencia contactoEmergencia;
    private DatosBancarios datosBancarios;

    // --- Habilidades, cada una con su propia tarifa por hora ---
    private List<Habilidad> habilidades;

    /**
     * Solo se piden los datos mínimos para identificar a la persona.
     * El resto se completa con los setters, porque a veces no se tienen todos
     * el primer día (por ejemplo, la cuenta bancaria).
     */
    public Persona(String nombre, String tipoDocumento, String documentoIdentidad, Rol rol) {
        this.nombre = nombre;
        this.tipoDocumento = tipoDocumento;
        this.documentoIdentidad = documentoIdentidad;
        this.rol = rol;
        this.habilidades = new ArrayList<>();
    }

    // --- Métodos para manejar las habilidades ---

    /**
     * Agrega una habilidad. Si la persona ya tenía ese tipo de actividad,
     * solo se actualiza la tarifa (no se repite la habilidad).
     */
    public void agregarHabilidad(Habilidad nueva) {
        Habilidad existente = obtenerHabilidad(nueva.getTipoActividad());
        if (existente != null) {
            existente.setTarifaPorHora(nueva.getTarifaPorHora());
        } else {
            habilidades.add(nueva);
        }
    }

    public void quitarHabilidad(TipoActividad tipo) {
        Habilidad existente = obtenerHabilidad(tipo);
        if (existente != null) {
            habilidades.remove(existente);
        }
    }

    // Devuelve la habilidad de ese tipo, o null si la persona no la tiene
    public Habilidad obtenerHabilidad(TipoActividad tipo) {
        for (Habilidad habilidad : habilidades) {
            if (habilidad.getTipoActividad() == tipo) {
                return habilidad;
            }
        }
        return null;
    }

    public boolean tieneHabilidad(TipoActividad tipo) {
        return obtenerHabilidad(tipo) != null;
    }

    /**
     * Tarifa por hora general de la persona: la más baja de sus habilidades.
     * Se usa cuando no se sabe en qué actividad trabajó. Devuelve 0 si no tiene habilidades.
     */
    public double getTarifaPorHora() {
        double menor = 0;
        for (Habilidad habilidad : habilidades) {
            if (menor == 0 || habilidad.getTarifaPorHora() < menor) {
                menor = habilidad.getTarifaPorHora();
            }
        }
        return menor;
    }

    // Texto del rol para mostrar en las tablas, por ejemplo "Director de obra"
    public String getTipoPersona() {
        return rol.getEtiqueta();
    }

    // PILAR EVIDENCIADO: Encapsulamiento (Métodos Getters y Setters públicos)
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getDocumentoIdentidad() {
        return documentoIdentidad;
    }

    public void setDocumentoIdentidad(String documentoIdentidad) {
        this.documentoIdentidad = documentoIdentidad;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(LocalDate fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public TipoVinculacion getTipoVinculacion() {
        return tipoVinculacion;
    }

    public void setTipoVinculacion(TipoVinculacion tipoVinculacion) {
        this.tipoVinculacion = tipoVinculacion;
    }

    public DatosSeguridadSocial getSeguridadSocial() {
        return seguridadSocial;
    }

    public void setSeguridadSocial(DatosSeguridadSocial seguridadSocial) {
        this.seguridadSocial = seguridadSocial;
    }

    public ContactoEmergencia getContactoEmergencia() {
        return contactoEmergencia;
    }

    public void setContactoEmergencia(ContactoEmergencia contactoEmergencia) {
        this.contactoEmergencia = contactoEmergencia;
    }

    public DatosBancarios getDatosBancarios() {
        return datosBancarios;
    }

    public void setDatosBancarios(DatosBancarios datosBancarios) {
        this.datosBancarios = datosBancarios;
    }

    public List<Habilidad> getHabilidades() {
        return habilidades;
    }

    // Texto con el que la persona aparece en las listas desplegables de la vista
    @Override
    public String toString() {
        return nombre + " (" + documentoIdentidad + ")";
    }
}
