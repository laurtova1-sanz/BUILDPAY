package modelo;

// PILAR EVIDENCIADO: Herencia (Uso de 'extends' para heredar de Persona)
// No tiene atributos propios: hereda todos los datos de Persona.
// Su tarifa ahora está en sus habilidades (por ejemplo BASICO o ALTURAS).
public class Obrero extends Persona {

    public Obrero(String nombre, String tipoDocumento, String documentoIdentidad) {
        // Uso de 'super' para invocar el constructor de la clase padre
        super(nombre, tipoDocumento, documentoIdentidad, Rol.OBRERO);
    }
}
