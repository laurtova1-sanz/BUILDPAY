package modelo;

// PILAR EVIDENCIADO: Encapsulamiento
// Una habilidad o certificación de la persona, con la tarifa que se le paga
// por cada hora que trabaje en ese tipo de actividad.
// Ejemplo: la misma persona puede cobrar 12.000 por hora en BASICO
// y 18.000 por hora en ALTURAS.
public class Habilidad {

    private TipoActividad tipoActividad;
    private double tarifaPorHora;

    public Habilidad(TipoActividad tipoActividad, double tarifaPorHora) {
        this.tipoActividad = tipoActividad;
        this.tarifaPorHora = tarifaPorHora;
    }

    // Getters y Setters
    public TipoActividad getTipoActividad() {
        return tipoActividad;
    }

    public void setTipoActividad(TipoActividad tipoActividad) {
        this.tipoActividad = tipoActividad;
    }

    public double getTarifaPorHora() {
        return tarifaPorHora;
    }

    public void setTarifaPorHora(double tarifaPorHora) {
        this.tarifaPorHora = tarifaPorHora;
    }

    // Texto con el que aparece en las listas de la vista, por ejemplo "Trabajo en alturas ($18000/h)"
    @Override
    public String toString() {
        return tipoActividad.getEtiqueta() + " ($" + (long) tarifaPorHora + "/h)";
    }
}
