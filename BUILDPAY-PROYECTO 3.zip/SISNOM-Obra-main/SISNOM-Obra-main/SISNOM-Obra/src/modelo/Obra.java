package modelo;

import java.util.ArrayList;
import java.util.List;

// PILAR EVIDENCIADO: Encapsulamiento
public class Obra {

    private String nombre;
    private String ubicacion;

    // --- Plan de obra ---
    private TipoConstruccion tipoConstruccion;
    private int numeroPisos;
    private double alturaMetros;
    private boolean trabajoEnAlturas;
    private boolean espaciosConfinados;

    // PILAR EVIDENCIADO: Polimorfismo (una sola lista de Persona guarda obreros y directores de obra)
    private List<Persona> personalAsignado;
    // Cronograma semanal de la obra
    private List<ActividadSemanal> actividades;

    public Obra(String nombre, String ubicacion, TipoConstruccion tipoConstruccion, int numeroPisos,
                double alturaMetros, boolean trabajoEnAlturas, boolean espaciosConfinados) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.tipoConstruccion = tipoConstruccion;
        this.numeroPisos = numeroPisos;
        this.alturaMetros = alturaMetros;
        this.trabajoEnAlturas = trabajoEnAlturas;
        this.espaciosConfinados = espaciosConfinados;
        this.personalAsignado = new ArrayList<>();
        this.actividades = new ArrayList<>();
    }

    // Agrega a la persona si todavía no estaba. Devuelve false si ya estaba asignada.
    public boolean asignarPersona(Persona persona) {
        if (personalAsignado.contains(persona)) {
            return false;
        }
        personalAsignado.add(persona);
        return true;
    }

    public boolean tienePersonaAsignada(Persona persona) {
        return personalAsignado.contains(persona);
    }

    public void agregarActividad(ActividadSemanal actividad) {
        actividades.add(actividad);
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public TipoConstruccion getTipoConstruccion() {
        return tipoConstruccion;
    }

    public void setTipoConstruccion(TipoConstruccion tipoConstruccion) {
        this.tipoConstruccion = tipoConstruccion;
    }

    public int getNumeroPisos() {
        return numeroPisos;
    }

    public void setNumeroPisos(int numeroPisos) {
        this.numeroPisos = numeroPisos;
    }

    public double getAlturaMetros() {
        return alturaMetros;
    }

    public void setAlturaMetros(double alturaMetros) {
        this.alturaMetros = alturaMetros;
    }

    public boolean isTrabajoEnAlturas() {
        return trabajoEnAlturas;
    }

    public void setTrabajoEnAlturas(boolean trabajoEnAlturas) {
        this.trabajoEnAlturas = trabajoEnAlturas;
    }

    public boolean isEspaciosConfinados() {
        return espaciosConfinados;
    }

    public void setEspaciosConfinados(boolean espaciosConfinados) {
        this.espaciosConfinados = espaciosConfinados;
    }

    public List<Persona> getPersonalAsignado() {
        return personalAsignado;
    }

    public List<ActividadSemanal> getActividades() {
        return actividades;
    }

    // Texto con el que la obra aparece en las listas desplegables de la vista
    @Override
    public String toString() {
        return nombre;
    }
}
