package modelo;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

// PILAR EVIDENCIADO: Encapsulamiento
public class RegistroHoras {

    // Relaciones con las otras entidades.
    // Los dos son Persona: puede trabajar un obrero o un director de obra,
    // y quien autoriza el turno es un maestro o un director de obra.
    private Persona trabajador;
    private Obra obra;
    private Persona autorizadoPor;
    // En qué trabajó: define la tarifa con la que se pagan estas horas
    private TipoActividad tipoActividad;

    // Datos de tiempo según RF-03
    private LocalDate fecha;
    private LocalTime horaInicio;
    private LocalTime horaFin;

    public RegistroHoras(Persona trabajador, Obra obra, TipoActividad tipoActividad, Persona autorizadoPor,
                         LocalDate fecha, LocalTime horaInicio, LocalTime horaFin) {
        this.trabajador = trabajador;
        this.obra = obra;
        this.tipoActividad = tipoActividad;
        this.autorizadoPor = autorizadoPor;
        this.fecha = fecha;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
    }

    // Horas de este turno, con decimales (7:00 a 11:30 = 4.5 horas)
    public double calcularHoras() {
        long minutos = Duration.between(horaInicio, horaFin).toMinutes();
        return minutos / 60.0;
    }

    /**
     * Tarifa con la que se pagan estas horas: la de la habilidad en la que trabajó.
     * Si la persona ya no tiene esa habilidad, se usa su tarifa general.
     */
    public double getTarifaAplicada() {
        Habilidad habilidad = trabajador.obtenerHabilidad(tipoActividad);
        if (habilidad != null) {
            return habilidad.getTarifaPorHora();
        }
        return trabajador.getTarifaPorHora();
    }

    // Getters y Setters
    public Persona getTrabajador() {
        return trabajador;
    }

    public void setTrabajador(Persona trabajador) {
        this.trabajador = trabajador;
    }

    public Obra getObra() {
        return obra;
    }

    public void setObra(Obra obra) {
        this.obra = obra;
    }

    public Persona getAutorizadoPor() {
        return autorizadoPor;
    }

    public void setAutorizadoPor(Persona autorizadoPor) {
        this.autorizadoPor = autorizadoPor;
    }

    public TipoActividad getTipoActividad() {
        return tipoActividad;
    }

    public void setTipoActividad(TipoActividad tipoActividad) {
        this.tipoActividad = tipoActividad;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalTime getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(LocalTime horaFin) {
        this.horaFin = horaFin;
    }
}
