package modelo;

// PILAR EVIDENCIADO: Encapsulamiento (Agrupa los datos de seguridad social en una sola clase)
// La usa Persona para guardar la afiliación del trabajador (composición).
public class DatosSeguridadSocial {

    private String eps;
    private String arl;
    // Nivel de riesgo ARL de 1 a 5. En construcción normalmente es IV o V.
    private int nivelRiesgoArl;
    private String fondoPension;

    public DatosSeguridadSocial(String eps, String arl, int nivelRiesgoArl, String fondoPension) {
        this.eps = eps;
        this.arl = arl;
        this.nivelRiesgoArl = nivelRiesgoArl;
        this.fondoPension = fondoPension;
    }

    // Getters y Setters
    public String getEps() {
        return eps;
    }

    public void setEps(String eps) {
        this.eps = eps;
    }

    public String getArl() {
        return arl;
    }

    public void setArl(String arl) {
        this.arl = arl;
    }

    public int getNivelRiesgoArl() {
        return nivelRiesgoArl;
    }

    public void setNivelRiesgoArl(int nivelRiesgoArl) {
        this.nivelRiesgoArl = nivelRiesgoArl;
    }

    public String getFondoPension() {
        return fondoPension;
    }

    public void setFondoPension(String fondoPension) {
        this.fondoPension = fondoPension;
    }
}
