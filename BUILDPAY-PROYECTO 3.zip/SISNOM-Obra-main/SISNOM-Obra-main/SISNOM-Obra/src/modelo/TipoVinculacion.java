package modelo;

// Formas en que se contrata a una persona en la obra
public enum TipoVinculacion {
    POR_OBRA_LABOR("Por obra o labor"),
    POR_HORAS("Por horas"),
    DESTAJO("Destajo"),
    FIJO("Fijo");

    private final String etiqueta;

    TipoVinculacion(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    // Texto con el que aparece en las listas desplegables de la vista
    @Override
    public String toString() {
        return etiqueta;
    }
}
