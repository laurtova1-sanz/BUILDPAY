package modelo;

// Tipos de obra que maneja el sistema
public enum TipoConstruccion {
    CASA("Casa"),
    APARTAMENTO("Apartamento"),
    REMODELACION("Remodelación");

    private final String etiqueta;

    TipoConstruccion(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    // Texto con el que aparece en las listas desplegables de la vista
    @Override
    public String toString() {
        return etiqueta;
    }
}
