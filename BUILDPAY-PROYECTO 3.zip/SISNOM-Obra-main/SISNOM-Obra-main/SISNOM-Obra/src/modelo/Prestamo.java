package modelo;

import java.time.LocalDate;

// PILAR EVIDENCIADO: Encapsulamiento
public class Prestamo {

    // Persona: el préstamo puede ser de un obrero o de un director de obra
    private Persona persona;
    private double montoInicial;
    private double saldoPendiente;
    private LocalDate fecha;

    public Prestamo(Persona persona, double montoInicial, LocalDate fecha) {
        this.persona = persona;
        this.montoInicial = montoInicial;
        // Al registrar un préstamo nuevo, el saldo pendiente es igual al monto total prestado
        this.saldoPendiente = montoInicial;
        this.fecha = fecha;
    }

    // Método para reducir el saldo pendiente cuando se aplica un descuento en la nómina
    public void aplicarDescuento(double montoDescontado) {
        if (montoDescontado <= this.saldoPendiente) {
            this.saldoPendiente -= montoDescontado;
        } else {
            this.saldoPendiente = 0;
        }
    }

    // Getters y Setters
    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public double getMontoInicial() {
        return montoInicial;
    }

    public void setMontoInicial(double montoInicial) {
        this.montoInicial = montoInicial;
    }

    public double getSaldoPendiente() {
        return saldoPendiente;
    }

    public void setSaldoPendiente(double saldoPendiente) {
        this.saldoPendiente = saldoPendiente;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
}
