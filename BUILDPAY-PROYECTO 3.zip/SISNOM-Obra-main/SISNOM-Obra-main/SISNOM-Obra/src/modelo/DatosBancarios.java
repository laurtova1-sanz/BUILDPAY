package modelo;

// PILAR EVIDENCIADO: Encapsulamiento (Agrupa los datos de la cuenta donde se paga la nómina)
// La usa Persona para saber a dónde consignar el pago (composición).
public class DatosBancarios {

    private String banco;
    // "Ahorros" o "Corriente"
    private String tipoCuenta;
    private String numeroCuenta;

    public DatosBancarios(String banco, String tipoCuenta, String numeroCuenta) {
        this.banco = banco;
        this.tipoCuenta = tipoCuenta;
        this.numeroCuenta = numeroCuenta;
    }

    // Getters y Setters
    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }
}
