package modelo;

import java.time.LocalDate;

// PILAR EVIDENCIADO: Encapsulamiento
public class Inasistencia {

    // Persona: la falta puede ser de un obrero o de un director de obra
    private Persona persona;
    private LocalDate fecha;
    private String motivo;

    // Constructor completo
    public Inasistencia(Persona persona, LocalDate fecha, String motivo) {
        this.persona = persona;
        this.fecha = fecha;
        this.motivo = motivo;
    }

    // Constructor sobrecargado para cuando el motivo es opcional y no se proporciona
    public Inasistencia(Persona persona, LocalDate fecha) {
        this.persona = persona;
        this.fecha = fecha;
        this.motivo = "Sin justificar";
    }

    // Getters y Setters
    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
}
