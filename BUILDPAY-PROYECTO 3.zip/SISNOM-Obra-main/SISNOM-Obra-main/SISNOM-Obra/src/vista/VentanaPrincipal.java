package vista;

import com.formdev.flatlaf.FlatLightLaf;
import controlador.InasistenciaController;
import controlador.NominaController;
import controlador.ObraController;
import controlador.PersonaController;
import controlador.PrestamoController;
import controlador.RegistroHorasController;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.format.DateTimeParseException;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import modelo.ActividadSemanal;
import modelo.ContactoEmergencia;
import modelo.DatosBancarios;
import modelo.DatosSeguridadSocial;
import modelo.DirectorObra;
import modelo.Habilidad;
import modelo.Inasistencia;
import modelo.Nomina;
import modelo.Obra;
import modelo.Obrero;
import modelo.Persona;
import modelo.Prestamo;
import modelo.RegistroHoras;
import modelo.Rol;
import modelo.TipoActividad;
import modelo.TipoConstruccion;
import modelo.TipoVinculacion;

/**
 * Ventana principal de BUILDPAY.
 * Cada pestaña lee sus campos, llama al controlador que corresponde
 * y vuelve a cargar su tabla.
 * Los controladores guardan los datos en la base de datos SQLite (buildpay.db).
 */
public class VentanaPrincipal extends JFrame {

    // ---------------- Estilo (colores y letras de toda la aplicación) ----------------

    static final Color COLOR_AZUL = new Color(31, 58, 95);          // cabecera y encabezados
    static final Color COLOR_NARANJA = new Color(242, 140, 40);     // botones (color de obra)
    static final Color COLOR_FONDO = new Color(244, 246, 248);      // fondo general
    static final Color COLOR_FILA_ALTERNA = new Color(234, 240, 247);
    static final Color COLOR_BORDE = new Color(200, 208, 218);
    static final Color COLOR_TEXTO = new Color(40, 40, 40);

    static final Font FUENTE_NORMAL = new Font("Segoe UI", Font.PLAIN, 14);
    static final Font FUENTE_NEGRITA = new Font("Segoe UI", Font.BOLD, 14);
    static final Font FUENTE_TITULO = new Font("Segoe UI", Font.BOLD, 26);

    // Niveles de riesgo ARL como se escriben en Colombia (en construcción normalmente IV o V)
    private static final String[] NIVELES_RIESGO = {"I", "II", "III", "IV", "V"};

    // ---------------- Controladores ----------------
    // Son static para que se creen una sola vez, aunque se cierre sesión
    // y se entre con otro usuario. El orden importa: primero se carga el personal,
    // porque los demás controladores lo necesitan para reconstruir los datos guardados.

    private static PersonaController personaController = new PersonaController();
    private static ObraController obraController = new ObraController(personaController);
    private static RegistroHorasController horasController =
            new RegistroHorasController(personaController, obraController);
    private static InasistenciaController inasistenciaController =
            new InasistenciaController(personaController);
    private static PrestamoController prestamoController = new PrestamoController(personaController);
    private static NominaController nominaController =
            new NominaController(personaController, prestamoController);

    // ---------------- Componentes de cada pestaña ----------------

    // Personal: identificación
    private JTextField txtNombre = crearCampo(16);
    private JComboBox<String> cmbTipoDocumento = crearCombo(new String[]{"CC", "CE", "PPT", "TI", "Pasaporte"});
    private JTextField txtDocumento = crearCampo(16);
    private JTextField txtFechaNacimiento = crearCampo(16);
    private JComboBox<String> cmbGenero = crearCombo(new String[]{"Masculino", "Femenino", "Otro"});
    private JTextField txtDireccion = crearCampo(16);
    private JTextField txtTelefono = crearCampo(16);
    // Personal: vinculación y seguridad social
    private JComboBox<Rol> cmbRol = crearCombo(Rol.values());
    private JTextField txtFechaIngreso = crearCampo(16);
    private JComboBox<TipoVinculacion> cmbVinculacion = crearCombo(TipoVinculacion.values());
    private JTextField txtEps = crearCampo(16);
    private JTextField txtArl = crearCampo(16);
    private JComboBox<String> cmbRiesgo = crearCombo(NIVELES_RIESGO);
    private JTextField txtFondoPension = crearCampo(16);
    // Personal: contacto de emergencia, banco y primera habilidad
    private JTextField txtContactoNombre = crearCampo(16);
    private JTextField txtContactoParentesco = crearCampo(16);
    private JTextField txtContactoTelefono = crearCampo(16);
    private JTextField txtBanco = crearCampo(16);
    private JComboBox<String> cmbTipoCuenta = crearCombo(new String[]{"Ahorros", "Corriente"});
    private JTextField txtNumeroCuenta = crearCampo(16);
    private JComboBox<TipoActividad> cmbHabilidadInicial = crearCombo(TipoActividad.values());
    private JTextField txtTarifaInicial = crearCampo(16);
    private DefaultTableModel modeloPersonal = new DefaultTableModel(
            new String[]{"Nombre", "Documento", "Rol", "Vinculación", "Ingreso", "EPS",
                         "ARL (riesgo)", "Pensión", "Teléfono", "Habilidades"}, 0);

    // Habilidades
    private JComboBox<Persona> cmbPersonaHabilidad = crearCombo();
    private JComboBox<TipoActividad> cmbTipoHabilidad = crearCombo(TipoActividad.values());
    private JTextField txtTarifaHabilidad = crearCampo();
    private DefaultTableModel modeloHabilidades = new DefaultTableModel(
            new String[]{"Persona", "Documento", "Rol", "Habilidad", "Tarifa por hora"}, 0);

    // Obras
    private JTextField txtNombreObra = crearCampo();
    private JTextField txtUbicacionObra = crearCampo();
    private JComboBox<TipoConstruccion> cmbTipoConstruccion = crearCombo(TipoConstruccion.values());
    private JTextField txtPisos = crearCampo();
    private JTextField txtAltura = crearCampo();
    private JCheckBox chkAlturas = crearCasilla("Implica trabajo en alturas");
    private JCheckBox chkConfinados = crearCasilla("Implica espacios confinados");
    private JComboBox<Obra> cmbObraAsignar = crearCombo();
    private JComboBox<Persona> cmbPersonaAsignar = crearCombo();
    private DefaultTableModel modeloObras = new DefaultTableModel(
            new String[]{"Nombre", "Ubicación", "Tipo", "Pisos", "Altura (m)", "Alturas",
                         "Confinados", "Personal asignado"}, 0);

    // Cronograma semanal
    private JComboBox<Obra> cmbObraActividad = crearCombo();
    private JTextField txtSemana = crearCampo();
    private JTextField txtNombreActividad = crearCampo();
    private JComboBox<TipoActividad> cmbTipoRequerido = crearCombo(TipoActividad.values());
    private JComboBox<ActividadSemanal> cmbActividad = crearCombo();
    private JComboBox<Persona> cmbPersonaActividad = crearCombo();
    private DefaultTableModel modeloActividades = new DefaultTableModel(
            new String[]{"Obra", "Semana", "Actividad", "Habilidad requerida", "Personal asignado"}, 0);

    // Registro de horas
    private JComboBox<Persona> cmbTrabajadorHoras = crearCombo();
    private JComboBox<Obra> cmbObraHoras = crearCombo();
    private JComboBox<TipoActividad> cmbTipoHoras = crearCombo();
    private JComboBox<Persona> cmbAutorizadoPor = crearCombo();
    private JTextField txtFechaHoras = crearCampo();
    private JTextField txtHoraInicio = crearCampo();
    private JTextField txtHoraFin = crearCampo();
    private DefaultTableModel modeloHoras = new DefaultTableModel(
            new String[]{"Trabajador", "Obra", "Actividad", "Autorizado por", "Fecha",
                         "Hora inicio", "Hora fin", "Horas", "Tarifa", "Valor"}, 0);

    // Inasistencias
    private JComboBox<Persona> cmbPersonaInasistencia = crearCombo();
    private JTextField txtFechaInasistencia = crearCampo();
    private JTextField txtMotivoInasistencia = crearCampo();
    private DefaultTableModel modeloInasistencias = new DefaultTableModel(
            new String[]{"Persona", "Rol", "Fecha", "Motivo"}, 0);

    // Préstamos
    private JComboBox<Persona> cmbPersonaPrestamo = crearCombo();
    private JTextField txtMontoPrestamo = crearCampo();
    private JTextField txtFechaPrestamo = crearCampo();
    private DefaultTableModel modeloPrestamos = new DefaultTableModel(
            new String[]{"Persona", "Rol", "Monto inicial", "Saldo pendiente", "Fecha"}, 0);

    // Nómina
    private JComboBox<Persona> cmbPersonaNomina = crearCombo();
    private JTextField txtInicioNomina = crearCampo();
    private JTextField txtFinNomina = crearCampo();
    private DefaultTableModel modeloNominas = new DefaultTableModel(
            new String[]{"Persona", "Rol", "Periodo inicio", "Periodo fin", "Horas trabajadas",
                         "Pago bruto", "Desc. inasistencias", "Desc. préstamo", "Pago neto"}, 0);

    public VentanaPrincipal(Rol rol) {
        setTitle("BUILDPAY - " + rol.getEtiqueta());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1320, 830);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_FONDO);
        setLayout(new BorderLayout());

        JTabbedPane pestanas = new JTabbedPane();
        pestanas.setFont(FUENTE_NEGRITA);
        pestanas.setBackground(Color.WHITE);

        pestanas.addTab("Personal", crearPanelPersonal());              // RF-01
        pestanas.addTab("Habilidades", crearPanelHabilidades());
        pestanas.addTab("Obras", crearPanelObras());                    // RF-02
        pestanas.addTab("Cronograma", crearPanelCronograma());
        pestanas.addTab("Registro de horas", crearPanelHoras());        // RF-03 / RF-04
        pestanas.addTab("Inasistencias", crearPanelInasistencias());
        pestanas.addTab("Préstamos", crearPanelPrestamos());
        pestanas.addTab("Nómina", crearPanelNomina());                  // RF-07 / RF-08

        // El director de obra maneja la obra en campo: sus obras, el cronograma
        // y la autorización de horas. Las demás pestañas son del maestro.
        if (rol == Rol.DIRECTOR_OBRA) {
            for (int i = pestanas.getTabCount() - 1; i >= 0; i--) {
                String titulo = pestanas.getTitleAt(i);
                if (!titulo.equals("Obras") && !titulo.equals("Cronograma")
                        && !titulo.equals("Registro de horas")) {
                    pestanas.removeTabAt(i);
                }
            }
        }

        add(crearCabecera(rol), BorderLayout.NORTH);
        add(pestanas, BorderLayout.CENTER);

        // Al abrir la ventana se cargan las tablas y los combos con lo que ya está registrado
        cargarPersonal();
        cargarHabilidades();
        cargarObras();
        cargarActividades();
        cargarHoras();
        cargarInasistencias();
        cargarPrestamos();
        cargarNominas();
        cargarCombos();
    }

    // ---------------- Cabecera ----------------

    private JPanel crearCabecera(Rol rol) {
        JLabel lblNombre = new JLabel("<html>BUILD<font color='#F28C28'>PAY</font></html>");
        lblNombre.setFont(FUENTE_TITULO);
        lblNombre.setForeground(Color.WHITE);

        JLabel lblDescripcion = new JLabel("Sistema de nómina para obras de construcción");
        lblDescripcion.setFont(FUENTE_NORMAL);
        lblDescripcion.setForeground(new Color(205, 215, 228));

        JPanel izquierda = new JPanel(new GridLayout(2, 1));
        izquierda.setOpaque(false);
        izquierda.add(lblNombre);
        izquierda.add(lblDescripcion);

        JLabel lblRol = new JLabel("Usuario: " + rol.getEtiqueta());
        lblRol.setFont(FUENTE_NEGRITA);
        lblRol.setForeground(Color.WHITE);

        JButton btnSalir = crearBoton("Cerrar sesión");
        btnSalir.addActionListener(e -> cerrarSesion());

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 8));
        derecha.setOpaque(false);
        derecha.add(lblRol);
        derecha.add(btnSalir);

        JPanel cabecera = new JPanel(new BorderLayout());
        cabecera.setBackground(COLOR_AZUL);
        cabecera.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 4, 0, COLOR_NARANJA),
                BorderFactory.createEmptyBorder(12, 20, 12, 20)));
        cabecera.add(izquierda, BorderLayout.WEST);
        cabecera.add(derecha, BorderLayout.EAST);
        return cabecera;
    }

    private void cerrarSesion() {
        new VentanaLogin().setVisible(true);
        dispose();
    }

    // ---------------- Pestaña Personal ----------------

    private JPanel crearPanelPersonal() {
        JPanel identificacion = crearFormulario("Identificación");
        agregarFila(identificacion, 0, "Nombre completo:", txtNombre);
        agregarFila(identificacion, 1, "Tipo de documento:", cmbTipoDocumento);
        agregarFila(identificacion, 2, "Número de documento:", txtDocumento);
        agregarFila(identificacion, 3, "Nacimiento (AAAA-MM-DD):", txtFechaNacimiento);
        agregarFila(identificacion, 4, "Género:", cmbGenero);
        agregarFila(identificacion, 5, "Dirección:", txtDireccion);
        agregarFila(identificacion, 6, "Teléfono:", txtTelefono);

        JPanel vinculacion = crearFormulario("Vinculación y seguridad social");
        agregarFila(vinculacion, 0, "Rol:", cmbRol);
        agregarFila(vinculacion, 1, "Ingreso (AAAA-MM-DD):", txtFechaIngreso);
        agregarFila(vinculacion, 2, "Tipo de vinculación:", cmbVinculacion);
        agregarFila(vinculacion, 3, "EPS:", txtEps);
        agregarFila(vinculacion, 4, "ARL:", txtArl);
        agregarFila(vinculacion, 5, "Nivel de riesgo ARL:", cmbRiesgo);
        agregarFila(vinculacion, 6, "Fondo de pensión:", txtFondoPension);
        cmbRiesgo.setSelectedIndex(3); // IV, lo normal en construcción

        JPanel contacto = crearFormulario("Emergencia, banco y habilidad");
        agregarFila(contacto, 0, "Contacto de emergencia:", txtContactoNombre);
        agregarFila(contacto, 1, "Parentesco:", txtContactoParentesco);
        agregarFila(contacto, 2, "Teléfono del contacto:", txtContactoTelefono);
        agregarFila(contacto, 3, "Banco:", txtBanco);
        agregarFila(contacto, 4, "Tipo de cuenta:", cmbTipoCuenta);
        agregarFila(contacto, 5, "Número de cuenta:", txtNumeroCuenta);
        agregarFila(contacto, 6, "Habilidad principal:", cmbHabilidadInicial);
        agregarFila(contacto, 7, "Tarifa por hora:", txtTarifaInicial);

        // Al elegir maestro o director de obra, se sugiere la habilidad de supervisión
        cmbRol.addActionListener(e -> {
            if (cmbRol.getSelectedItem() == Rol.OBRERO) {
                cmbHabilidadInicial.setSelectedItem(TipoActividad.BASICO);
            } else {
                cmbHabilidadInicial.setSelectedItem(TipoActividad.SUPERVISION);
            }
        });
        cmbRol.setSelectedItem(Rol.OBRERO);

        JPanel formularios = new JPanel(new GridLayout(1, 3, 12, 0));
        formularios.setOpaque(false);
        formularios.add(identificacion);
        formularios.add(vinculacion);
        formularios.add(contacto);

        JButton btnRegistrar = crearBoton("Registrar persona");
        btnRegistrar.addActionListener(e -> registrarPersona());
        JLabel lblAyuda = new JLabel("Obligatorio: nombre, documento y tarifa. "
                + "Si la fecha de ingreso va vacía, se usa la de hoy.");
        lblAyuda.setFont(FUENTE_NORMAL);
        lblAyuda.setForeground(COLOR_TEXTO);

        JPanel filaBoton = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        filaBoton.setOpaque(false);
        filaBoton.add(btnRegistrar);
        filaBoton.add(lblAyuda);

        JPanel arriba = new JPanel(new BorderLayout(0, 10));
        arriba.setOpaque(false);
        arriba.add(formularios, BorderLayout.CENTER);
        arriba.add(filaBoton, BorderLayout.SOUTH);

        return armarPanel(arriba, crearTabla(modeloPersonal));
    }

    private void registrarPersona() {
        String nombre = txtNombre.getText().trim();
        String documento = txtDocumento.getText().trim();

        if (nombre.isEmpty() || documento.isEmpty()) {
            mostrarError("Escribe el nombre y el número de documento.");
            return;
        }
        if (personaController.existeDocumento(documento)) {
            mostrarError("Ya hay una persona registrada con el documento " + documento + ".");
            return;
        }

        // La fecha de nacimiento es opcional, pero si se escribe debe ser válida
        LocalDate nacimiento = null;
        if (!txtFechaNacimiento.getText().trim().isEmpty()) {
            nacimiento = leerFecha(txtFechaNacimiento, "La fecha de nacimiento");
            if (nacimiento == null) {
                return;
            }
            // En Colombia no se puede contratar a menores de edad en construcción
            if (Period.between(nacimiento, LocalDate.now()).getYears() < 18) {
                mostrarError("La persona debe ser mayor de edad para trabajar en obra.");
                return;
            }
        }
        LocalDate ingreso = LocalDate.now();
        if (!txtFechaIngreso.getText().trim().isEmpty()) {
            ingreso = leerFecha(txtFechaIngreso, "La fecha de ingreso");
            if (ingreso == null) {
                return;
            }
        }
        double tarifa = leerNumero(txtTarifaInicial, "La tarifa por hora");
        if (tarifa < 0) {
            return;
        }

        // PILAR EVIDENCIADO: Polimorfismo (la variable es Persona, el objeto es Obrero o DirectorObra)
        Rol rol = (Rol) cmbRol.getSelectedItem();
        String tipoDocumento = (String) cmbTipoDocumento.getSelectedItem();
        Persona persona;
        if (rol == Rol.OBRERO) {
            persona = new Obrero(nombre, tipoDocumento, documento);
        } else {
            persona = new DirectorObra(nombre, tipoDocumento, documento);
            persona.setRol(rol); // director de obra o maestro
        }

        persona.setFechaNacimiento(nacimiento);
        persona.setGenero((String) cmbGenero.getSelectedItem());
        persona.setDireccion(txtDireccion.getText().trim());
        persona.setTelefono(txtTelefono.getText().trim());
        persona.setFechaIngreso(ingreso);
        persona.setTipoVinculacion((TipoVinculacion) cmbVinculacion.getSelectedItem());
        persona.setSeguridadSocial(new DatosSeguridadSocial(txtEps.getText().trim(), txtArl.getText().trim(),
                cmbRiesgo.getSelectedIndex() + 1, txtFondoPension.getText().trim()));
        persona.setContactoEmergencia(new ContactoEmergencia(txtContactoNombre.getText().trim(),
                txtContactoParentesco.getText().trim(), txtContactoTelefono.getText().trim()));
        persona.setDatosBancarios(new DatosBancarios(txtBanco.getText().trim(),
                (String) cmbTipoCuenta.getSelectedItem(), txtNumeroCuenta.getText().trim()));
        persona.agregarHabilidad(new Habilidad((TipoActividad) cmbHabilidadInicial.getSelectedItem(), tarifa));

        boolean guardado = personaController.registrarPersona(persona);
        if (guardado) {
            limpiar(txtNombre, txtDocumento, txtFechaNacimiento, txtDireccion, txtTelefono, txtFechaIngreso,
                    txtEps, txtArl, txtFondoPension, txtContactoNombre, txtContactoParentesco,
                    txtContactoTelefono, txtBanco, txtNumeroCuenta, txtTarifaInicial);
            cargarPersonal();
            cargarHabilidades();
            cargarCombos();
        } else {
            mostrarError("No se pudo registrar a la persona.");
        }
    }

    private void cargarPersonal() {
        modeloPersonal.setRowCount(0);
        for (Persona p : personaController.obtenerTodoElPersonal()) {
            DatosSeguridadSocial ss = p.getSeguridadSocial();
            String arl = "";
            if (ss != null && ss.getNivelRiesgoArl() >= 1) {
                arl = ss.getArl() + " (" + NIVELES_RIESGO[ss.getNivelRiesgoArl() - 1] + ")";
            }
            modeloPersonal.addRow(new Object[]{
                p.getNombre(), p.getTipoDocumento() + " " + p.getDocumentoIdentidad(), p.getTipoPersona(),
                p.getTipoVinculacion() == null ? "" : p.getTipoVinculacion().getEtiqueta(),
                p.getFechaIngreso() == null ? "" : p.getFechaIngreso(),
                ss == null ? "" : ss.getEps(), arl, ss == null ? "" : ss.getFondoPension(),
                p.getTelefono(), textoHabilidades(p)
            });
        }
    }

    // ---------------- Pestaña Habilidades ----------------

    private JPanel crearPanelHabilidades() {
        JPanel formulario = crearFormulario("Habilidades y tarifas por persona");
        agregarFila(formulario, 0, "Persona:", cmbPersonaHabilidad);
        agregarFila(formulario, 1, "Habilidad:", cmbTipoHabilidad);
        agregarFila(formulario, 2, "Tarifa por hora:", txtTarifaHabilidad);

        JButton btnAgregar = crearBoton("Agregar o actualizar");
        btnAgregar.addActionListener(e -> agregarHabilidad());
        JButton btnQuitar = crearBoton("Quitar habilidad");
        btnQuitar.addActionListener(e -> quitarHabilidad());
        agregarFila(formulario, 3, "", filaDeBotones(btnAgregar, btnQuitar));

        return armarPanel(formulario, crearTabla(modeloHabilidades));
    }

    private void agregarHabilidad() {
        Persona persona = (Persona) cmbPersonaHabilidad.getSelectedItem();
        if (persona == null) {
            mostrarError("No hay personal registrado. Regístralo en la pestaña Personal.");
            return;
        }
        double tarifa = leerNumero(txtTarifaHabilidad, "La tarifa por hora");
        if (tarifa < 0) {
            return;
        }
        TipoActividad tipo = (TipoActividad) cmbTipoHabilidad.getSelectedItem();
        // Si ya la tenía, el controlador solo actualiza la tarifa
        personaController.agregarHabilidad(persona, tipo, tarifa);
        txtTarifaHabilidad.setText("");
        cargarHabilidades();
        cargarPersonal();
        cargarTiposHoras();
    }

    private void quitarHabilidad() {
        Persona persona = (Persona) cmbPersonaHabilidad.getSelectedItem();
        TipoActividad tipo = (TipoActividad) cmbTipoHabilidad.getSelectedItem();
        if (persona == null) {
            mostrarError("No hay personal registrado. Regístralo en la pestaña Personal.");
            return;
        }
        if (persona.getHabilidades().size() == 1 && persona.tieneHabilidad(tipo)) {
            mostrarError("Cada persona debe tener al menos una habilidad para poder pagarle.");
            return;
        }
        if (!personaController.quitarHabilidad(persona, tipo)) {
            mostrarError(persona.getNombre() + " no tiene la habilidad " + tipo.getEtiqueta() + ".");
            return;
        }
        cargarHabilidades();
        cargarPersonal();
        cargarTiposHoras();
    }

    private void cargarHabilidades() {
        modeloHabilidades.setRowCount(0);
        for (Persona p : personaController.obtenerTodoElPersonal()) {
            for (Habilidad h : p.getHabilidades()) {
                modeloHabilidades.addRow(new Object[]{
                    p.getNombre(), p.getDocumentoIdentidad(), p.getTipoPersona(),
                    h.getTipoActividad().getEtiqueta(), dinero(h.getTarifaPorHora())
                });
            }
        }
    }

    // ---------------- Pestaña Obras ----------------

    private JPanel crearPanelObras() {
        // Formulario 1: crear la obra con su plan
        JPanel formularioObra = crearFormulario("Nueva obra");
        agregarFila(formularioObra, 0, "Nombre de la obra:", txtNombreObra);
        agregarFila(formularioObra, 1, "Ubicación:", txtUbicacionObra);
        agregarFila(formularioObra, 2, "Tipo de construcción:", cmbTipoConstruccion);
        agregarFila(formularioObra, 3, "Número de pisos:", txtPisos);
        agregarFila(formularioObra, 4, "Altura (metros):", txtAltura);
        agregarFila(formularioObra, 5, "", chkAlturas);
        agregarFila(formularioObra, 6, "", chkConfinados);

        JButton btnRegistrar = crearBoton("Registrar obra");
        btnRegistrar.addActionListener(e -> registrarObra());
        agregarFila(formularioObra, 7, "", btnRegistrar);

        // Formulario 2: asignar personal a una obra que ya existe
        JPanel formularioAsignar = crearFormulario("Asignar personal a una obra");
        agregarFila(formularioAsignar, 0, "Obra:", cmbObraAsignar);
        agregarFila(formularioAsignar, 1, "Persona:", cmbPersonaAsignar);

        JButton btnAsignar = crearBoton("Asignar a la obra");
        btnAsignar.addActionListener(e -> asignarPersonaAObra());
        agregarFila(formularioAsignar, 2, "", btnAsignar);

        JPanel formularios = new JPanel(new GridLayout(1, 2, 12, 0));
        formularios.setOpaque(false);
        formularios.add(formularioObra);
        formularios.add(formularioAsignar);

        return armarPanel(formularios, crearTabla(modeloObras));
    }

    private void registrarObra() {
        String nombre = txtNombreObra.getText().trim();
        String ubicacion = txtUbicacionObra.getText().trim();

        if (nombre.isEmpty() || ubicacion.isEmpty()) {
            mostrarError("Escribe el nombre y la ubicación de la obra.");
            return;
        }
        if (obraController.existeObra(nombre)) {
            mostrarError("Ya existe una obra con el nombre " + nombre + ".");
            return;
        }
        int pisos = leerEntero(txtPisos, "El número de pisos");
        if (pisos < 0) {
            return;
        }
        double altura = leerNumero(txtAltura, "La altura");
        if (altura < 0) {
            return;
        }
        // En Colombia, trabajar desde 2 metros de altura se considera trabajo en alturas
        if (altura >= 2 && !chkAlturas.isSelected()) {
            chkAlturas.setSelected(true);
            JOptionPane.showMessageDialog(this,
                    "La obra mide " + altura + " m. Desde 2 metros se considera trabajo en alturas,\n"
                    + "así que se marcó esa casilla.", "Trabajo en alturas", JOptionPane.INFORMATION_MESSAGE);
        }

        Obra obra = new Obra(nombre, ubicacion, (TipoConstruccion) cmbTipoConstruccion.getSelectedItem(),
                pisos, altura, chkAlturas.isSelected(), chkConfinados.isSelected());
        boolean guardado = obraController.registrarObra(obra);
        if (guardado) {
            limpiar(txtNombreObra, txtUbicacionObra, txtPisos, txtAltura);
            chkAlturas.setSelected(false);
            chkConfinados.setSelected(false);
            cargarObras();
            cargarCombos();
        } else {
            mostrarError("No se pudo registrar la obra.");
        }
    }

    private void asignarPersonaAObra() {
        Obra obra = (Obra) cmbObraAsignar.getSelectedItem();
        Persona persona = (Persona) cmbPersonaAsignar.getSelectedItem();

        if (obra == null) {
            mostrarError("Primero registra una obra y selecciónala.");
            return;
        }
        if (persona == null) {
            mostrarError("No hay personal registrado. Regístralo en la pestaña Personal.");
            return;
        }

        // El controlador devuelve false si la persona ya estaba en esa obra
        boolean asignado = obraController.asignarPersonaAObra(obra, persona);
        if (!asignado) {
            mostrarError(persona.getNombre() + " ya está asignado a la obra " + obra.getNombre() + ".");
            return;
        }
        cargarObras();
    }

    private void cargarObras() {
        modeloObras.setRowCount(0);
        for (Obra o : obraController.obtenerTodasLasObras()) {
            modeloObras.addRow(new Object[]{
                o.getNombre(), o.getUbicacion(), o.getTipoConstruccion().getEtiqueta(), o.getNumeroPisos(),
                o.getAlturaMetros(), siNo(o.isTrabajoEnAlturas()), siNo(o.isEspaciosConfinados()),
                textoPersonal(o.getPersonalAsignado())
            });
        }
    }

    // ---------------- Pestaña Cronograma ----------------

    private JPanel crearPanelCronograma() {
        // Formulario 1: crear una actividad de la semana
        JPanel formularioActividad = crearFormulario("Nueva actividad semanal");
        agregarFila(formularioActividad, 0, "Obra:", cmbObraActividad);
        agregarFila(formularioActividad, 1, "Semana número:", txtSemana);
        agregarFila(formularioActividad, 2, "Actividad:", txtNombreActividad);
        agregarFila(formularioActividad, 3, "Habilidad requerida:", cmbTipoRequerido);

        JButton btnCrear = crearBoton("Crear actividad");
        btnCrear.addActionListener(e -> registrarActividad());
        agregarFila(formularioActividad, 4, "", btnCrear);

        // Formulario 2: asignar personal, pasando por el validador de competencias
        JPanel formularioAsignar = crearFormulario("Asignar personal a una actividad");
        agregarFila(formularioAsignar, 0, "Actividad:", cmbActividad);
        agregarFila(formularioAsignar, 1, "Persona:", cmbPersonaActividad);

        JButton btnAsignar = crearBoton("Asignar a la actividad");
        btnAsignar.addActionListener(e -> asignarPersonaAActividad());
        agregarFila(formularioAsignar, 2, "", btnAsignar);

        JPanel formularios = new JPanel(new GridLayout(1, 2, 12, 0));
        formularios.setOpaque(false);
        formularios.add(formularioActividad);
        formularios.add(formularioAsignar);

        return armarPanel(formularios, crearTabla(modeloActividades));
    }

    private void registrarActividad() {
        Obra obra = (Obra) cmbObraActividad.getSelectedItem();
        if (obra == null) {
            mostrarError("Primero registra una obra en la pestaña Obras.");
            return;
        }
        int semana = leerEntero(txtSemana, "El número de semana");
        if (semana < 0) {
            return;
        }
        String nombre = txtNombreActividad.getText().trim();
        if (nombre.isEmpty()) {
            mostrarError("Escribe el nombre de la actividad.");
            return;
        }
        TipoActividad tipo = (TipoActividad) cmbTipoRequerido.getSelectedItem();

        boolean guardado = obraController.registrarActividad(obra, semana, nombre, tipo);
        if (!guardado) {
            mostrarError("La obra " + obra.getNombre() + " ya tiene la actividad \"" + nombre
                    + "\" en la semana " + semana + ".");
            return;
        }
        limpiar(txtNombreActividad);
        cargarActividades();
        cargarCombos();
    }

    private void asignarPersonaAActividad() {
        ActividadSemanal actividad = (ActividadSemanal) cmbActividad.getSelectedItem();
        Persona persona = (Persona) cmbPersonaActividad.getSelectedItem();

        if (actividad == null) {
            mostrarError("Primero crea una actividad.");
            return;
        }
        if (persona == null) {
            mostrarError("No hay personal registrado. Regístralo en la pestaña Personal.");
            return;
        }

        // ValidadorCompetencias, paso 1: si no tiene la habilidad, se bloquea
        if (!obraController.puedeHacerActividad(persona, actividad)) {
            mostrarError(persona.getNombre() + " no tiene la habilidad "
                    + actividad.getTipoRequerido().getEtiqueta() + ", que pide esta actividad.\n"
                    + "Agrégasela en la pestaña Habilidades si está certificado.");
            return;
        }
        // ValidadorCompetencias, paso 2: si está sobrecalificado y hay alguien más barato, se advierte
        String advertencia = obraController.obtenerAdvertenciaCompetencia(persona, actividad);
        if (advertencia != null) {
            int respuesta = JOptionPane.showConfirmDialog(this,
                    advertencia + "\n\n¿Asignar a " + persona.getNombre() + " de todas formas?",
                    "Persona sobrecalificada", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (respuesta != JOptionPane.YES_OPTION) {
                return;
            }
        }

        boolean asignado = obraController.asignarPersonaAActividad(actividad, persona);
        if (!asignado) {
            mostrarError(persona.getNombre() + " ya está asignado a esta actividad.");
            return;
        }
        cargarActividades();
        cargarObras(); // si no estaba en la obra, también quedó asignado a ella
    }

    private void cargarActividades() {
        modeloActividades.setRowCount(0);
        for (ActividadSemanal a : obraController.obtenerTodasLasActividades()) {
            modeloActividades.addRow(new Object[]{
                a.getObra().getNombre(), a.getSemana(), a.getNombre(),
                a.getTipoRequerido().getEtiqueta(), textoPersonal(a.getPersonalAsignado())
            });
        }
    }

    // ---------------- Pestaña Registro de horas ----------------

    private JPanel crearPanelHoras() {
        JPanel formulario = crearFormulario("Registro de horas trabajadas");
        agregarFila(formulario, 0, "Trabajador:", cmbTrabajadorHoras);
        agregarFila(formulario, 1, "Obra:", cmbObraHoras);
        agregarFila(formulario, 2, "Actividad realizada:", cmbTipoHoras);
        agregarFila(formulario, 3, "Autorizado por:", cmbAutorizadoPor);
        agregarFila(formulario, 4, "Fecha (AAAA-MM-DD):", txtFechaHoras);
        agregarFila(formulario, 5, "Hora inicio (HH:MM):", txtHoraInicio);
        agregarFila(formulario, 6, "Hora fin (HH:MM):", txtHoraFin);

        // Al cambiar de trabajador, solo se muestran las actividades para las que tiene habilidad
        cmbTrabajadorHoras.addActionListener(e -> cargarTiposHoras());

        JButton btnRegistrar = crearBoton("Registrar horas");
        btnRegistrar.addActionListener(e -> registrarHoras());
        agregarFila(formulario, 7, "", btnRegistrar);

        return armarPanel(formulario, crearTabla(modeloHoras));
    }

    private void cargarTiposHoras() {
        cmbTipoHoras.removeAllItems();
        Persona trabajador = (Persona) cmbTrabajadorHoras.getSelectedItem();
        if (trabajador != null) {
            for (Habilidad h : trabajador.getHabilidades()) {
                cmbTipoHoras.addItem(h.getTipoActividad());
            }
        }
    }

    private void registrarHoras() {
        Persona trabajador = (Persona) cmbTrabajadorHoras.getSelectedItem();
        Obra obra = (Obra) cmbObraHoras.getSelectedItem();
        TipoActividad tipo = (TipoActividad) cmbTipoHoras.getSelectedItem();
        Persona autorizadoPor = (Persona) cmbAutorizadoPor.getSelectedItem();

        if (trabajador == null || obra == null || autorizadoPor == null) {
            mostrarError("Debes tener registrados y seleccionados un trabajador, una obra\n"
                    + "y un maestro o director de obra que autorice el turno.");
            return;
        }
        if (tipo == null) {
            mostrarError(trabajador.getNombre() + " no tiene habilidades registradas.");
            return;
        }
        if (trabajador == autorizadoPor) {
            mostrarError("Una persona no puede autorizar su propio turno.");
            return;
        }
        if (!obra.tienePersonaAsignada(trabajador)) {
            mostrarError(trabajador.getNombre() + " no está asignado a la obra " + obra.getNombre()
                    + ".\nAsígnalo primero en la pestaña Obras.");
            return;
        }

        LocalDate fecha = leerFecha(txtFechaHoras, "La fecha");
        if (fecha == null) {
            return;
        }
        LocalTime inicio = leerHora(txtHoraInicio, "La hora de inicio");
        if (inicio == null) {
            return;
        }
        LocalTime fin = leerHora(txtHoraFin, "La hora de fin");
        if (fin == null) {
            return;
        }
        if (!horasController.esHorarioValido(inicio, fin)) {
            mostrarError("La hora de fin debe ser mayor que la hora de inicio.");
            return;
        }

        RegistroHoras nuevo = new RegistroHoras(trabajador, obra, tipo, autorizadoPor, fecha, inicio, fin);

        // RF-04: el controlador busca si el trabajador ya tiene horas que se crucen con las nuevas
        RegistroHoras conflicto = horasController.buscarConflicto(nuevo);
        if (conflicto != null) {
            JOptionPane.showMessageDialog(this,
                    "No se puede registrar: " + trabajador.getNombre() + " ya tiene horas en ese horario.\n\n"
                    + "Obra en conflicto: " + conflicto.getObra().getNombre() + "\n"
                    + "Fecha: " + conflicto.getFecha() + "\n"
                    + "Horario: " + conflicto.getHoraInicio() + " a " + conflicto.getHoraFin(),
                    "Cruce de horarios", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!horasController.registrarHoras(nuevo)) {
            mostrarError("No se pudieron registrar las horas.");
            return;
        }
        limpiar(txtHoraInicio, txtHoraFin);
        cargarHoras();
    }

    private void cargarHoras() {
        modeloHoras.setRowCount(0);
        for (RegistroHoras r : horasController.obtenerTodosLosRegistros()) {
            double horas = r.calcularHoras();
            modeloHoras.addRow(new Object[]{
                r.getTrabajador().getNombre(), r.getObra().getNombre(), r.getTipoActividad().getEtiqueta(),
                r.getAutorizadoPor().getNombre(), r.getFecha(), r.getHoraInicio(), r.getHoraFin(),
                String.format("%.2f", horas), dinero(r.getTarifaAplicada()),
                dinero(horas * r.getTarifaAplicada())
            });
        }
    }

    // ---------------- Pestaña Inasistencias ----------------

    private JPanel crearPanelInasistencias() {
        JPanel formulario = crearFormulario("Registro de inasistencias");
        agregarFila(formulario, 0, "Persona:", cmbPersonaInasistencia);
        agregarFila(formulario, 1, "Fecha (AAAA-MM-DD):", txtFechaInasistencia);
        agregarFila(formulario, 2, "Motivo (opcional):", txtMotivoInasistencia);

        JButton btnRegistrar = crearBoton("Registrar inasistencia");
        btnRegistrar.addActionListener(e -> registrarInasistencia());
        agregarFila(formulario, 3, "", btnRegistrar);

        return armarPanel(formulario, crearTabla(modeloInasistencias));
    }

    private void registrarInasistencia() {
        Persona persona = (Persona) cmbPersonaInasistencia.getSelectedItem();
        if (persona == null) {
            mostrarError("No hay personal registrado. Regístralo en la pestaña Personal.");
            return;
        }
        LocalDate fecha = leerFecha(txtFechaInasistencia, "La fecha");
        if (fecha == null) {
            return;
        }
        if (inasistenciaController.existeInasistencia(persona, fecha)) {
            mostrarError(persona.getNombre() + " ya tiene una inasistencia registrada el " + fecha + ".");
            return;
        }

        // Si el motivo va vacío, el controlador la guarda como "Sin justificar"
        String motivo = txtMotivoInasistencia.getText().trim();
        inasistenciaController.registrarInasistencia(persona, fecha, motivo);

        limpiar(txtFechaInasistencia, txtMotivoInasistencia);
        cargarInasistencias();
    }

    private void cargarInasistencias() {
        modeloInasistencias.setRowCount(0);
        for (Inasistencia i : inasistenciaController.obtenerTodasLasInasistencias()) {
            modeloInasistencias.addRow(new Object[]{
                i.getPersona().getNombre(), i.getPersona().getTipoPersona(), i.getFecha(), i.getMotivo()
            });
        }
    }

    // ---------------- Pestaña Préstamos ----------------

    private JPanel crearPanelPrestamos() {
        JPanel formulario = crearFormulario("Registro de préstamos");
        agregarFila(formulario, 0, "Persona:", cmbPersonaPrestamo);
        agregarFila(formulario, 1, "Monto inicial:", txtMontoPrestamo);
        agregarFila(formulario, 2, "Fecha (AAAA-MM-DD):", txtFechaPrestamo);

        JButton btnRegistrar = crearBoton("Registrar préstamo");
        btnRegistrar.addActionListener(e -> registrarPrestamo());
        agregarFila(formulario, 3, "", btnRegistrar);

        return armarPanel(formulario, crearTabla(modeloPrestamos));
    }

    private void registrarPrestamo() {
        Persona persona = (Persona) cmbPersonaPrestamo.getSelectedItem();
        if (persona == null) {
            mostrarError("No hay personal registrado. Regístralo en la pestaña Personal.");
            return;
        }
        double monto = leerNumero(txtMontoPrestamo, "El monto del préstamo");
        if (monto < 0) {
            return;
        }
        LocalDate fecha = leerFecha(txtFechaPrestamo, "La fecha");
        if (fecha == null) {
            return;
        }

        prestamoController.registrarPrestamo(persona, monto, fecha);
        limpiar(txtMontoPrestamo, txtFechaPrestamo);
        cargarPrestamos();
    }

    private void cargarPrestamos() {
        modeloPrestamos.setRowCount(0);
        for (Prestamo p : prestamoController.obtenerTodosLosPrestamos()) {
            modeloPrestamos.addRow(new Object[]{
                p.getPersona().getNombre(), p.getPersona().getTipoPersona(), dinero(p.getMontoInicial()),
                dinero(p.getSaldoPendiente()), p.getFecha()
            });
        }
    }

    // ---------------- Pestaña Nómina ----------------

    private JPanel crearPanelNomina() {
        JPanel formulario = crearFormulario("Generación de nómina (obreros, maestros y directores de obra)");
        agregarFila(formulario, 0, "Persona:", cmbPersonaNomina);
        agregarFila(formulario, 1, "Fecha inicio (AAAA-MM-DD):", txtInicioNomina);
        agregarFila(formulario, 2, "Fecha fin (AAAA-MM-DD):", txtFinNomina);

        JButton btnGenerar = crearBoton("Generar nómina");
        btnGenerar.addActionListener(e -> generarNomina());
        JButton btnTodos = crearBoton("Generar para todo el personal");
        btnTodos.addActionListener(e -> generarNominaTodos());
        agregarFila(formulario, 3, "", filaDeBotones(btnGenerar, btnTodos));

        return armarPanel(formulario, crearTabla(modeloNominas));
    }

    // Lee y revisa las dos fechas del periodo. Devuelve null si alguna está mal.
    private LocalDate[] leerPeriodo() {
        LocalDate inicio = leerFecha(txtInicioNomina, "La fecha de inicio");
        if (inicio == null) {
            return null;
        }
        LocalDate fin = leerFecha(txtFinNomina, "La fecha de fin");
        if (fin == null) {
            return null;
        }
        if (fin.isBefore(inicio)) {
            mostrarError("La fecha de fin no puede ser anterior a la fecha de inicio.");
            return null;
        }
        return new LocalDate[]{inicio, fin};
    }

    /**
     * Devuelve por qué no se le puede generar nómina a la persona en ese periodo,
     * o null si sí se puede.
     */
    private String motivoParaNoGenerar(Persona persona, LocalDate inicio, LocalDate fin) {
        // No se paga dos veces el mismo periodo (además se descontaría el préstamo dos veces)
        if (nominaController.existeNominaEnPeriodo(persona, inicio, fin)) {
            return "ya tiene una nómina que incluye fechas de ese periodo";
        }
        if (horasController.obtenerRegistrosEnPeriodo(persona, inicio, fin).isEmpty()) {
            return "no tiene horas registradas entre el " + inicio + " y el " + fin;
        }
        return null;
    }

    // Junta los datos de los otros controladores y le pide el cálculo al de nómina (RF-07)
    private Nomina generarNominaDe(Persona persona, LocalDate inicio, LocalDate fin) {
        // 1. Registros de horas de la persona dentro del periodo (cada uno con su tarifa)
        List<RegistroHoras> registros = horasController.obtenerRegistrosEnPeriodo(persona, inicio, fin);
        // 2. Inasistencias de la persona dentro del periodo
        List<Inasistencia> inasistencias =
                inasistenciaController.obtenerInasistenciasEnPeriodo(persona, inicio, fin);
        // 3. Préstamo de la persona que todavía tiene saldo (null si no debe nada)
        Prestamo prestamoActivo = prestamoController.obtenerPrestamoActivo(persona);
        // 4. El cálculo lo hace el controlador
        return nominaController.generarNomina(persona, inicio, fin, registros, inasistencias, prestamoActivo);
    }

    private void generarNomina() {
        Persona persona = (Persona) cmbPersonaNomina.getSelectedItem();
        if (persona == null) {
            mostrarError("No hay personal registrado. Regístralo en la pestaña Personal.");
            return;
        }
        LocalDate[] periodo = leerPeriodo();
        if (periodo == null) {
            return;
        }
        String motivo = motivoParaNoGenerar(persona, periodo[0], periodo[1]);
        if (motivo != null) {
            mostrarError(persona.getNombre() + " " + motivo + ".");
            return;
        }

        Nomina nomina = generarNominaDe(persona, periodo[0], periodo[1]);
        int faltas = inasistenciaController.obtenerInasistenciasEnPeriodo(persona, periodo[0], periodo[1]).size();
        cargarNominas();
        cargarPrestamos(); // el saldo del préstamo cambió

        JOptionPane.showMessageDialog(this,
                "Nómina de " + persona.getNombre() + " (" + persona.getTipoPersona() + ")\n"
                + "Periodo: " + periodo[0] + " al " + periodo[1] + "\n\n"
                + "Horas trabajadas: " + String.format("%.2f", nomina.getTotalHorasTrabajadas()) + "\n"
                + "Pago bruto: " + dinero(nomina.getPagoBruto()) + "\n"
                + "Descuento por inasistencias (" + faltas + "): "
                + dinero(nomina.getDescuentoInasistencias()) + "\n"
                + "Descuento por préstamo: " + dinero(nomina.getDescuentoPrestamo()) + "\n\n"
                + "PAGO NETO: " + dinero(nomina.getPagoNeto()),
                "Desglose de la nómina", JOptionPane.INFORMATION_MESSAGE);
    }

    // Genera la nómina de todas las personas que tengan horas en el periodo
    private void generarNominaTodos() {
        LocalDate[] periodo = leerPeriodo();
        if (periodo == null) {
            return;
        }
        int generadas = 0;
        double totalNeto = 0;
        String omitidos = "";
        for (Persona persona : personaController.obtenerTodoElPersonal()) {
            String motivo = motivoParaNoGenerar(persona, periodo[0], periodo[1]);
            if (motivo == null) {
                totalNeto += generarNominaDe(persona, periodo[0], periodo[1]).getPagoNeto();
                generadas++;
            } else {
                omitidos += "\n- " + persona.getNombre() + ": " + motivo;
            }
        }
        cargarNominas();
        cargarPrestamos();

        String mensaje = "Nóminas generadas: " + generadas + "\nTotal a pagar: " + dinero(totalNeto);
        if (!omitidos.isEmpty()) {
            mensaje += "\n\nNo se generó nómina para:" + omitidos;
        }
        JOptionPane.showMessageDialog(this, mensaje, "Nómina del personal", JOptionPane.INFORMATION_MESSAGE);
    }

    private void cargarNominas() {
        modeloNominas.setRowCount(0);
        for (Nomina n : nominaController.obtenerNominasGeneradas()) {
            modeloNominas.addRow(new Object[]{
                n.getPersona().getNombre(), n.getPersona().getTipoPersona(),
                n.getFechaInicioPeriodo(), n.getFechaFinPeriodo(),
                String.format("%.2f", n.getTotalHorasTrabajadas()),
                dinero(n.getPagoBruto()), dinero(n.getDescuentoInasistencias()),
                dinero(n.getDescuentoPrestamo()), dinero(n.getPagoNeto())
            });
        }
    }

    // ---------------- Combos ----------------

    // Vuelve a llenar todos los combos. Se llama cada vez que se registra
    // una persona, una obra o una actividad, para que aparezcan en las demás pestañas.
    private void cargarCombos() {
        List<Persona> personal = personaController.obtenerTodoElPersonal();
        llenarCombo(cmbPersonaHabilidad, personal);
        llenarCombo(cmbPersonaAsignar, personal);
        llenarCombo(cmbPersonaActividad, personal);
        llenarCombo(cmbTrabajadorHoras, personal);
        llenarCombo(cmbPersonaInasistencia, personal);
        llenarCombo(cmbPersonaPrestamo, personal);
        llenarCombo(cmbPersonaNomina, personal);
        llenarCombo(cmbAutorizadoPor, personaController.obtenerSupervisores());

        List<Obra> obras = obraController.obtenerTodasLasObras();
        llenarCombo(cmbObraAsignar, obras);
        llenarCombo(cmbObraActividad, obras);
        llenarCombo(cmbObraHoras, obras);

        llenarCombo(cmbActividad, obraController.obtenerTodasLasActividades());
        cargarTiposHoras();
    }

    // Los combos guardan los objetos; lo que se ve es lo que devuelve su toString()
    private <T> void llenarCombo(JComboBox<T> combo, List<T> elementos) {
        combo.removeAllItems();
        for (T elemento : elementos) {
            combo.addItem(elemento);
        }
    }

    // ---------------- Textos para las tablas ----------------

    // Junta los nombres separados por coma para mostrarlos en una sola celda
    private String textoPersonal(List<Persona> personas) {
        String texto = "";
        for (Persona p : personas) {
            if (!texto.isEmpty()) {
                texto += ", ";
            }
            texto += p.getNombre();
        }
        return texto;
    }

    private String textoHabilidades(Persona persona) {
        String texto = "";
        for (Habilidad h : persona.getHabilidades()) {
            if (!texto.isEmpty()) {
                texto += ", ";
            }
            texto += h.toString();
        }
        return texto;
    }

    private String siNo(boolean valor) {
        return valor ? "Sí" : "No";
    }

    // ---------------- Validaciones ----------------

    // Devuelve la fecha escrita en el campo, o null si está vacía o mal escrita
    private LocalDate leerFecha(JTextField campo, String nombreCampo) {
        String texto = campo.getText().trim();
        if (texto.isEmpty()) {
            mostrarError(nombreCampo + " no puede estar vacía.");
            return null;
        }
        try {
            return LocalDate.parse(texto);
        } catch (DateTimeParseException ex) {
            mostrarError(nombreCampo + " debe tener el formato AAAA-MM-DD. Ejemplo: 2026-03-15");
            return null;
        }
    }

    // Devuelve la hora escrita en el campo, o null si está vacía o mal escrita
    private LocalTime leerHora(JTextField campo, String nombreCampo) {
        String texto = campo.getText().trim();
        if (texto.isEmpty()) {
            mostrarError(nombreCampo + " no puede estar vacía.");
            return null;
        }
        try {
            return LocalTime.parse(texto);
        } catch (DateTimeParseException ex) {
            mostrarError(nombreCampo + " debe tener el formato HH:MM. Ejemplo: 07:30");
            return null;
        }
    }

    // Devuelve el número escrito en el campo, o -1 si está vacío, no es número o no es mayor a 0
    private double leerNumero(JTextField campo, String nombreCampo) {
        String texto = campo.getText().trim();
        if (texto.isEmpty()) {
            mostrarError(nombreCampo + " no puede estar vacío.");
            return -1;
        }
        try {
            double numero = Double.parseDouble(texto);
            if (numero <= 0) {
                mostrarError(nombreCampo + " debe ser mayor a 0.");
                return -1;
            }
            return numero;
        } catch (NumberFormatException ex) {
            mostrarError(nombreCampo + " debe ser un número. Ejemplo: 12500");
            return -1;
        }
    }

    // Igual que leerNumero, pero para números enteros (pisos, semanas)
    private int leerEntero(JTextField campo, String nombreCampo) {
        String texto = campo.getText().trim();
        if (texto.isEmpty()) {
            mostrarError(nombreCampo + " no puede estar vacío.");
            return -1;
        }
        try {
            int numero = Integer.parseInt(texto);
            if (numero <= 0) {
                mostrarError(nombreCampo + " debe ser mayor a 0.");
                return -1;
            }
            return numero;
        } catch (NumberFormatException ex) {
            mostrarError(nombreCampo + " debe ser un número entero. Ejemplo: 3");
            return -1;
        }
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Dato inválido", JOptionPane.ERROR_MESSAGE);
    }

    private void limpiar(JTextField... campos) {
        for (JTextField campo : campos) {
            campo.setText("");
        }
    }

    private String dinero(double valor) {
        return String.format("$ %,.2f", valor);
    }

    // ---------------- Métodos de diseño (se usan en todas las pestañas) ----------------

    // Aplica FlatLaf, el Look and Feel moderno. Se llama antes de abrir la primera ventana.
    static void aplicarEstilo() {
        FlatLightLaf.setup();
        UIManager.put("Component.arc", 8);
        UIManager.put("TabbedPane.selectedBackground", Color.WHITE);
        UIManager.put("TabbedPane.underlineColor", COLOR_NARANJA);
    }

    static JTextField crearCampo() {
        return crearCampo(20);
    }

    static JTextField crearCampo(int columnas) {
        JTextField campo = new JTextField(columnas);
        campo.setFont(FUENTE_NORMAL);
        return campo;
    }

    // Combo vacío que se llena después (personas, obras, actividades)
    static <T> JComboBox<T> crearCombo() {
        JComboBox<T> combo = new JComboBox<>();
        combo.setFont(FUENTE_NORMAL);
        combo.setBackground(Color.WHITE);
        combo.setPreferredSize(new Dimension(240, 28));
        return combo;
    }

    // Combo con opciones fijas (por ejemplo los valores de un enum)
    static <T> JComboBox<T> crearCombo(T[] opciones) {
        JComboBox<T> combo = crearCombo();
        for (T opcion : opciones) {
            combo.addItem(opcion);
        }
        combo.setPreferredSize(new Dimension(180, 28));
        return combo;
    }

    static JButton crearBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.setFont(FUENTE_NEGRITA);
        boton.setBackground(COLOR_NARANJA);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return boton;
    }

    private JCheckBox crearCasilla(String texto) {
        JCheckBox casilla = new JCheckBox(texto);
        casilla.setFont(FUENTE_NORMAL);
        casilla.setBackground(Color.WHITE);
        return casilla;
    }

    // Pone varios botones uno al lado del otro
    private JPanel filaDeBotones(JButton... botones) {
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        fila.setOpaque(false);
        for (int i = 0; i < botones.length; i++) {
            if (i > 0) {
                fila.add(Box.createHorizontalStrut(10));
            }
            fila.add(botones[i]);
        }
        return fila;
    }

    // Panel blanco con un título, donde van las etiquetas y los campos
    private JPanel crearFormulario(String titulo) {
        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBackground(Color.WHITE);
        formulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(COLOR_BORDE),
                        titulo, 0, 0, FUENTE_NEGRITA, COLOR_AZUL),
                BorderFactory.createEmptyBorder(6, 10, 10, 10)));
        return formulario;
    }

    // Agrega una fila al formulario: etiqueta a la izquierda y campo a la derecha
    private void agregarFila(JPanel formulario, int fila, String etiqueta, JComponent campo) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);
        g.anchor = GridBagConstraints.WEST;
        g.gridy = fila;

        JLabel lbl = new JLabel(etiqueta);
        lbl.setFont(FUENTE_NORMAL);
        lbl.setForeground(COLOR_TEXTO);
        g.gridx = 0;
        formulario.add(lbl, g);

        g.gridx = 1;
        formulario.add(campo, g);

        // Espacio vacío que empuja todo hacia la izquierda
        g.gridx = 2;
        g.weightx = 1;
        formulario.add(new JLabel(), g);
    }

    // Tabla con encabezado azul, filas de dos colores y sin edición
    private JScrollPane crearTabla(DefaultTableModel modelo) {
        JTable tabla = new JTable(modelo);
        tabla.setFont(FUENTE_NORMAL);
        tabla.setRowHeight(26);
        tabla.setGridColor(COLOR_BORDE);
        tabla.setSelectionBackground(COLOR_NARANJA);
        tabla.setSelectionForeground(Color.WHITE);
        tabla.setDefaultEditor(Object.class, null); // las celdas no se pueden editar

        tabla.getTableHeader().setFont(FUENTE_NEGRITA);
        tabla.getTableHeader().setBackground(COLOR_AZUL);
        tabla.getTableHeader().setForeground(Color.WHITE);
        tabla.getTableHeader().setReorderingAllowed(false);

        tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object valor,
                    boolean seleccionada, boolean conFoco, int fila, int columna) {
                Component celda = super.getTableCellRendererComponent(
                        t, valor, seleccionada, conFoco, fila, columna);
                if (!seleccionada) {
                    if (fila % 2 == 0) {
                        celda.setBackground(Color.WHITE);
                    } else {
                        celda.setBackground(COLOR_FILA_ALTERNA);
                    }
                    celda.setForeground(COLOR_TEXTO);
                }
                return celda;
            }
        });

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.getViewport().setBackground(Color.WHITE);
        scroll.setBorder(BorderFactory.createLineBorder(COLOR_BORDE));
        return scroll;
    }

    // Une el formulario (arriba) con la tabla (abajo) dejando márgenes
    private JPanel armarPanel(JPanel formulario, JScrollPane tabla) {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setBackground(COLOR_FONDO);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.add(formulario, BorderLayout.NORTH);
        panel.add(tabla, BorderLayout.CENTER);
        return panel;
    }

    public static void main(String[] args) {
        // El programa arranca desde el login
        aplicarEstilo();
        SwingUtilities.invokeLater(() -> new VentanaLogin().setVisible(true));
    }
}
