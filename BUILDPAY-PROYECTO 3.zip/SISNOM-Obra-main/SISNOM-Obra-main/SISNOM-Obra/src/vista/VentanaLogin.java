package vista;

import controlador.AutenticacionController;
import java.awt.*;
import javax.swing.*;
import modelo.Rol;

/**
 * Ventana de inicio de sesión de BUILDPAY. Solo el Maestro y el Director de obra pueden entrar.
 * Los colores, las letras y los botones se toman de VentanaPrincipal
 * para que las dos ventanas se vean iguales.
 */
public class VentanaLogin extends JFrame {

    private AutenticacionController autenticacion = new AutenticacionController();
    private JTextField txtUsuario = VentanaPrincipal.crearCampo();
    private JPasswordField txtClave = new JPasswordField(20);

    public VentanaLogin() {
        setTitle("BUILDPAY - Iniciar sesión");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(crearCabecera(), BorderLayout.NORTH);
        add(crearFormulario(), BorderLayout.CENTER);

        pack();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    private JPanel crearCabecera() {
        JLabel lblNombre = new JLabel("<html>BUILD<font color='#F28C28'>PAY</font></html>", JLabel.CENTER);
        lblNombre.setFont(VentanaPrincipal.FUENTE_TITULO);
        lblNombre.setForeground(Color.WHITE);

        JLabel lblDescripcion = new JLabel("Sistema de nómina para obras de construcción", JLabel.CENTER);
        lblDescripcion.setFont(VentanaPrincipal.FUENTE_NORMAL);
        lblDescripcion.setForeground(new Color(205, 215, 228));

        JPanel cabecera = new JPanel(new GridLayout(2, 1, 0, 4));
        cabecera.setBackground(VentanaPrincipal.COLOR_AZUL);
        cabecera.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 4, 0, VentanaPrincipal.COLOR_NARANJA),
                BorderFactory.createEmptyBorder(22, 40, 22, 40)));
        cabecera.add(lblNombre);
        cabecera.add(lblDescripcion);
        return cabecera;
    }

    private JPanel crearFormulario() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(22, 35, 25, 35));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);
        g.anchor = GridBagConstraints.WEST;

        JLabel lblTitulo = new JLabel("Iniciar sesión");
        lblTitulo.setFont(VentanaPrincipal.FUENTE_NEGRITA.deriveFont(18f));
        lblTitulo.setForeground(VentanaPrincipal.COLOR_AZUL);
        g.gridx = 0; g.gridy = 0; g.gridwidth = 2;
        panel.add(lblTitulo, g);
        g.gridwidth = 1;

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(VentanaPrincipal.FUENTE_NORMAL);
        g.gridx = 0; g.gridy = 1;
        panel.add(lblUsuario, g);
        g.gridx = 1;
        panel.add(txtUsuario, g);

        JLabel lblClave = new JLabel("Contraseña:");
        lblClave.setFont(VentanaPrincipal.FUENTE_NORMAL);
        txtClave.setFont(VentanaPrincipal.FUENTE_NORMAL);
        g.gridx = 0; g.gridy = 2;
        panel.add(lblClave, g);
        g.gridx = 1;
        panel.add(txtClave, g);

        JButton btnIngresar = VentanaPrincipal.crearBoton("Ingresar");
        btnIngresar.addActionListener(e -> ingresar());
        g.gridx = 1; g.gridy = 3;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(14, 6, 6, 6);
        panel.add(btnIngresar, g);

        // Permite ingresar presionando Enter
        getRootPane().setDefaultButton(btnIngresar);

        return panel;
    }

    private void ingresar() {
        String usuario = txtUsuario.getText().trim();
        String clave = new String(txtClave.getPassword());

        if (usuario.isEmpty() || clave.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Escribe el usuario y la contraseña.",
                    "Faltan datos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Rol rol = autenticacion.iniciarSesion(usuario, clave);
        if (rol == null) {
            JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            txtClave.setText("");
            return;
        }

        new VentanaPrincipal(rol).setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        // Look and Feel moderno (FlatLaf) antes de abrir la primera ventana
        VentanaPrincipal.aplicarEstilo();
        SwingUtilities.invokeLater(() -> new VentanaLogin().setVisible(true));
    }
}
