package datos;

import java.util.List;
import modelo.Inasistencia;

// Guarda y consulta las inasistencias
public class InasistenciaDAO {

    private ConexionBD conexionBD = new ConexionBD();

    public void guardar(Inasistencia i) {
        conexionBD.ejecutar("INSERT INTO inasistencias VALUES (?, ?, ?)",
                i.getPersona().getDocumentoIdentidad(), i.getFecha(), i.getMotivo());
    }

    // Cada fila trae: persona, fecha, motivo
    public List<String[]> listar() {
        return conexionBD.consultar("SELECT * FROM inasistencias ORDER BY rowid");
    }
}
