package datos;

import java.util.List;
import modelo.RegistroHoras;

// Guarda y consulta los registros de horas trabajadas
public class RegistroHorasDAO {

    private ConexionBD conexionBD = new ConexionBD();

    public void guardar(RegistroHoras r) {
        conexionBD.ejecutar("INSERT INTO registros_horas VALUES (?, ?, ?, ?, ?, ?, ?)",
                r.getTrabajador().getDocumentoIdentidad(), r.getObra().getNombre(), r.getTipoActividad(),
                r.getAutorizadoPor().getDocumentoIdentidad(), r.getFecha(), r.getHoraInicio(), r.getHoraFin());
    }

    /**
     * Cada fila trae: trabajador, obra, tipo de actividad, autorizado por, fecha, hora inicio, hora fin.
     * El controlador se encarga de convertirlas en objetos RegistroHoras.
     */
    public List<String[]> listar() {
        return conexionBD.consultar("SELECT * FROM registros_horas ORDER BY rowid");
    }
}
