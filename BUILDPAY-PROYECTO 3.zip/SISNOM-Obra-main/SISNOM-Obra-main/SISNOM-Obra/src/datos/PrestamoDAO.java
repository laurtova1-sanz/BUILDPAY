package datos;

import java.util.ArrayList;
import java.util.List;
import modelo.Prestamo;

// Guarda y consulta los préstamos
public class PrestamoDAO {

    private static final String SQL_INSERTAR = "INSERT INTO prestamos VALUES (?, ?, ?, ?)";

    private ConexionBD conexionBD = new ConexionBD();

    public void guardar(Prestamo p) {
        conexionBD.ejecutar(SQL_INSERTAR, valores(p));
    }

    /**
     * Vuelve a guardar todos los préstamos con su saldo actual.
     * Se usa después de generar una nómina, porque el saldo pendiente cambia.
     * Se borra y se inserta todo junto: si algo falla, no se guarda nada a medias.
     */
    public void actualizarTodos(List<Prestamo> prestamos) {
        List<String> sentencias = new ArrayList<>();
        List<Object[]> valores = new ArrayList<>();
        sentencias.add("DELETE FROM prestamos");
        valores.add(new Object[]{});
        for (Prestamo p : prestamos) {
            sentencias.add(SQL_INSERTAR);
            valores.add(valores(p));
        }
        conexionBD.ejecutarTransaccion(sentencias, valores);
    }

    private Object[] valores(Prestamo p) {
        return new Object[]{p.getPersona().getDocumentoIdentidad(), p.getMontoInicial(),
            p.getSaldoPendiente(), p.getFecha()};
    }

    // Cada fila trae: persona, monto inicial, saldo pendiente, fecha
    public List<String[]> listar() {
        return conexionBD.consultar("SELECT * FROM prestamos ORDER BY rowid");
    }
}
