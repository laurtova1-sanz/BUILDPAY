package datos;

import java.util.ArrayList;
import java.util.List;
import modelo.ActividadSemanal;
import modelo.Obra;
import modelo.TipoConstruccion;

// Guarda y consulta las obras, su personal y su cronograma semanal
public class ObraDAO {

    private ConexionBD conexionBD = new ConexionBD();

    public void guardar(Obra o) {
        conexionBD.ejecutar("INSERT INTO obras VALUES (?, ?, ?, ?, ?, ?, ?)",
                o.getNombre(), o.getUbicacion(), o.getTipoConstruccion(), o.getNumeroPisos(),
                o.getAlturaMetros(), o.isTrabajoEnAlturas(), o.isEspaciosConfinados());
    }

    public void guardarPersonaAsignada(String nombreObra, String documento) {
        conexionBD.ejecutar("INSERT INTO obra_personal (obra, persona) VALUES (?, ?)", nombreObra, documento);
    }

    public void guardarActividad(ActividadSemanal a) {
        conexionBD.ejecutar("INSERT INTO actividades (obra, semana, nombre, tipo) VALUES (?, ?, ?, ?)",
                a.getObra().getNombre(), a.getSemana(), a.getNombre(), a.getTipoRequerido());
    }

    // La actividad se identifica por obra + semana + nombre
    public void guardarPersonaEnActividad(ActividadSemanal a, String documento) {
        conexionBD.ejecutar("INSERT INTO actividad_personal (obra, semana, actividad, persona) VALUES (?, ?, ?, ?)",
                a.getObra().getNombre(), a.getSemana(), a.getNombre(), documento);
    }

    // Devuelve las obras sin personal ni actividades. El controlador les agrega después lo demás.
    public List<Obra> listar() {
        List<Obra> obras = new ArrayList<>();
        for (String[] f : conexionBD.consultar("SELECT * FROM obras ORDER BY rowid")) {
            obras.add(new Obra(f[0], f[1], TipoConstruccion.valueOf(f[2]), Integer.parseInt(f[3]),
                    Double.parseDouble(f[4]), f[5].equals("1"), f[6].equals("1")));
        }
        return obras;
    }

    // Cada fila trae: obra, documento de la persona
    public List<String[]> listarPersonalAsignado() {
        return conexionBD.consultar("SELECT obra, persona FROM obra_personal ORDER BY rowid");
    }

    // Cada fila trae: obra, semana, nombre, tipo
    public List<String[]> listarActividades() {
        return conexionBD.consultar("SELECT obra, semana, nombre, tipo FROM actividades ORDER BY rowid");
    }

    // Cada fila trae: obra, semana, nombre de la actividad, documento de la persona
    public List<String[]> listarPersonalDeActividades() {
        return conexionBD.consultar(
                "SELECT obra, semana, actividad, persona FROM actividad_personal ORDER BY rowid");
    }
}
