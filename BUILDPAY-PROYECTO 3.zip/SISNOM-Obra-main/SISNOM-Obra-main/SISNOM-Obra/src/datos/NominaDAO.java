package datos;

import java.util.List;
import modelo.Nomina;

// Guarda y consulta las nóminas generadas
public class NominaDAO {

    private ConexionBD conexionBD = new ConexionBD();

    public void guardar(Nomina n) {
        conexionBD.ejecutar("INSERT INTO nominas VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                n.getPersona().getDocumentoIdentidad(), n.getFechaInicioPeriodo(), n.getFechaFinPeriodo(),
                n.getTotalHorasTrabajadas(), n.getPagoBruto(), n.getDescuentoInasistencias(),
                n.getDescuentoPrestamo(), n.getPagoNeto());
    }

    /**
     * Cada fila trae: persona, fecha inicio, fecha fin, horas, pago bruto,
     * descuento por inasistencias, descuento por préstamo, pago neto.
     */
    public List<String[]> listar() {
        return conexionBD.consultar("SELECT * FROM nominas ORDER BY rowid");
    }
}
