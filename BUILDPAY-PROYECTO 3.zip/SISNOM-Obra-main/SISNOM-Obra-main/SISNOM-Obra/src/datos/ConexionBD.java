package datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

// PILAR EVIDENCIADO: Abstracción (Oculta la complejidad de la conexión a los controladores)
// Los DAO solo escriben el SQL; aquí se abre la conexión, se ponen los valores y se cierra.
public class ConexionBD {

    // Ruta local donde se creará el archivo físico de la base de datos SQLite
    private static final String URL = "jdbc:sqlite:buildpay.db";

    // Son static para que las tablas se creen y el error se avise una sola vez
    private static boolean tablasCreadas = false;
    private static boolean errorAvisado = false;

    private Connection conexion;

    /**
     * Establece la conexión con la base de datos local.
     * Si el archivo 'buildpay.db' no existe, SQLite lo crea automáticamente.
     * Devuelve null si no se pudo conectar (por ejemplo, si falta el driver).
     */
    public Connection conectar() {
        try {
            // Carga el driver JDBC de SQLite exigido en los requerimientos de interfaz
            Class.forName("org.sqlite.JDBC");
            conexion = DriverManager.getConnection(URL);
            if (!tablasCreadas) {
                crearTablas();
                tablasCreadas = true;
            }
        } catch (ClassNotFoundException | SQLException e) {
            conexion = null;
            if (!errorAvisado) {
                System.err.println("Error al conectar con la base de datos: " + e.getMessage());
                System.err.println("El programa seguirá funcionando, pero los datos no se guardarán.");
                errorAvisado = true;
            }
        }
        return conexion;
    }

    /**
     * Cierra la conexión para liberar recursos y proteger la integridad de los datos (RNF-04).
     */
    public void desconectar() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }

    /**
     * Ejecuta un INSERT, UPDATE o DELETE. Cada ? del SQL se reemplaza por un valor, en orden.
     * Devuelve false si no se pudo guardar.
     */
    public boolean ejecutar(String sql, Object... valores) {
        List<String> sentencias = new ArrayList<>();
        sentencias.add(sql);
        List<Object[]> listaValores = new ArrayList<>();
        listaValores.add(valores);
        return ejecutarTransaccion(sentencias, listaValores);
    }

    /**
     * Ejecuta varias sentencias juntas (transacción): o se guardan todas o no se guarda ninguna.
     * La sentencia de la posición i usa los valores de la posición i.
     */
    public boolean ejecutarTransaccion(List<String> sentencias, List<Object[]> valores) {
        Connection con = conectar();
        if (con == null) {
            return false; // sin base de datos el programa sigue funcionando en memoria
        }
        try {
            con.setAutoCommit(false);
            for (int i = 0; i < sentencias.size(); i++) {
                PreparedStatement ps = con.prepareStatement(sentencias.get(i));
                ponerValores(ps, valores.get(i));
                ps.executeUpdate();
                ps.close();
            }
            con.commit();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al guardar en la base de datos: " + e.getMessage());
            try {
                con.rollback(); // se deshace lo que alcanzó a hacer
            } catch (SQLException ex) {
                System.err.println("Error al deshacer los cambios: " + ex.getMessage());
            }
            return false;
        } finally {
            desconectar();
        }
    }

    /**
     * Ejecuta un SELECT y devuelve cada fila como un arreglo de textos,
     * con las columnas en el mismo orden en que se pidieron en el SQL.
     */
    public List<String[]> consultar(String sql, Object... valores) {
        List<String[]> filas = new ArrayList<>();
        Connection con = conectar();
        if (con == null) {
            return filas;
        }
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ponerValores(ps, valores);
            ResultSet rs = ps.executeQuery();
            int columnas = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                String[] fila = new String[columnas];
                for (int i = 0; i < columnas; i++) {
                    fila[i] = rs.getString(i + 1);
                }
                filas.add(fila);
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.err.println("Error al consultar la base de datos: " + e.getMessage());
        } finally {
            desconectar();
        }
        return filas;
    }

    /**
     * Pone los valores en los ? del PreparedStatement.
     * Las fechas, horas y enums se guardan como texto; los boolean como 1 o 0.
     */
    private void ponerValores(PreparedStatement ps, Object[] valores) throws SQLException {
        for (int i = 0; i < valores.length; i++) {
            Object valor = valores[i];
            if (valor == null || valor instanceof String || valor instanceof Number) {
                ps.setObject(i + 1, valor);
            } else if (valor instanceof Boolean) {
                ps.setInt(i + 1, (Boolean) valor ? 1 : 0);
            } else if (valor instanceof Enum) {
                ps.setString(i + 1, ((Enum<?>) valor).name()); // ej. "ALTURAS"
            } else {
                ps.setString(i + 1, valor.toString()); // LocalDate y LocalTime
            }
        }
    }

    /**
     * Crea las tablas la primera vez. Las personas se identifican por su documento
     * y las obras por su nombre, igual que en las clases del modelo.
     */
    private void crearTablas() throws SQLException {
        Statement st = conexion.createStatement();
        st.executeUpdate("CREATE TABLE IF NOT EXISTS personas ("
                + "documento TEXT PRIMARY KEY, clase TEXT, nombre TEXT, tipo_documento TEXT, "
                + "fecha_nacimiento TEXT, genero TEXT, direccion TEXT, telefono TEXT, "
                + "rol TEXT, fecha_ingreso TEXT, tipo_vinculacion TEXT, "
                + "eps TEXT, arl TEXT, nivel_riesgo INTEGER, fondo_pension TEXT, "
                + "contacto_nombre TEXT, contacto_parentesco TEXT, contacto_telefono TEXT, "
                + "banco TEXT, tipo_cuenta TEXT, numero_cuenta TEXT)");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS habilidades ("
                + "persona TEXT, tipo TEXT, tarifa REAL)");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS obras ("
                + "nombre TEXT PRIMARY KEY, ubicacion TEXT, tipo_construccion TEXT, pisos INTEGER, "
                + "altura REAL, trabajo_alturas INTEGER, espacios_confinados INTEGER)");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS obra_personal ("
                + "obra TEXT, persona TEXT)");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS actividades ("
                + "obra TEXT, semana INTEGER, nombre TEXT, tipo TEXT)");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS actividad_personal ("
                + "obra TEXT, semana INTEGER, actividad TEXT, persona TEXT)");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS registros_horas ("
                + "trabajador TEXT, obra TEXT, tipo_actividad TEXT, autorizado_por TEXT, "
                + "fecha TEXT, hora_inicio TEXT, hora_fin TEXT)");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS inasistencias ("
                + "persona TEXT, fecha TEXT, motivo TEXT)");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS prestamos ("
                + "persona TEXT, monto_inicial REAL, saldo_pendiente REAL, fecha TEXT)");
        st.executeUpdate("CREATE TABLE IF NOT EXISTS nominas ("
                + "persona TEXT, fecha_inicio TEXT, fecha_fin TEXT, horas REAL, pago_bruto REAL, "
                + "desc_inasistencias REAL, desc_prestamo REAL, pago_neto REAL)");
        st.close();
    }
}
