package datos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import modelo.ContactoEmergencia;
import modelo.DatosBancarios;
import modelo.DatosSeguridadSocial;
import modelo.DirectorObra;
import modelo.Habilidad;
import modelo.Obrero;
import modelo.Persona;
import modelo.Rol;
import modelo.TipoActividad;
import modelo.TipoVinculacion;

// Guarda y consulta el personal (obreros y directores de obra) y sus habilidades
public class PersonaDAO {

    private ConexionBD conexionBD = new ConexionBD();

    // Guarda la persona y sus habilidades juntas (si algo falla, no se guarda nada)
    public void guardar(Persona p) {
        DatosSeguridadSocial ss = p.getSeguridadSocial();
        ContactoEmergencia ce = p.getContactoEmergencia();
        DatosBancarios db = p.getDatosBancarios();

        List<String> sentencias = new ArrayList<>();
        List<Object[]> valores = new ArrayList<>();
        sentencias.add("INSERT INTO personas VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        valores.add(new Object[]{
            p.getDocumentoIdentidad(), p.getClass().getSimpleName(), p.getNombre(), p.getTipoDocumento(),
            p.getFechaNacimiento(), p.getGenero(), p.getDireccion(), p.getTelefono(),
            p.getRol(), p.getFechaIngreso(), p.getTipoVinculacion(),
            ss == null ? null : ss.getEps(), ss == null ? null : ss.getArl(),
            ss == null ? null : ss.getNivelRiesgoArl(), ss == null ? null : ss.getFondoPension(),
            ce == null ? null : ce.getNombre(), ce == null ? null : ce.getParentesco(),
            ce == null ? null : ce.getTelefono(),
            db == null ? null : db.getBanco(), db == null ? null : db.getTipoCuenta(),
            db == null ? null : db.getNumeroCuenta()
        });
        agregarHabilidades(p, sentencias, valores);
        conexionBD.ejecutarTransaccion(sentencias, valores);
    }

    // Borra las habilidades guardadas de la persona y vuelve a guardar las actuales
    public void actualizarHabilidades(Persona p) {
        List<String> sentencias = new ArrayList<>();
        List<Object[]> valores = new ArrayList<>();
        sentencias.add("DELETE FROM habilidades WHERE persona = ?");
        valores.add(new Object[]{p.getDocumentoIdentidad()});
        agregarHabilidades(p, sentencias, valores);
        conexionBD.ejecutarTransaccion(sentencias, valores);
    }

    private void agregarHabilidades(Persona p, List<String> sentencias, List<Object[]> valores) {
        for (Habilidad h : p.getHabilidades()) {
            sentencias.add("INSERT INTO habilidades (persona, tipo, tarifa) VALUES (?, ?, ?)");
            valores.add(new Object[]{p.getDocumentoIdentidad(), h.getTipoActividad(), h.getTarifaPorHora()});
        }
    }

    // Reconstruye a cada persona con todos sus datos y sus habilidades
    public List<Persona> listar() {
        List<Persona> personas = new ArrayList<>();
        for (String[] f : conexionBD.consultar("SELECT * FROM personas ORDER BY rowid")) {
            // Columnas en el orden de la tabla: 0 documento, 1 clase, 2 nombre, 3 tipo_documento...
            Persona p;
            if (f[1].equals("Obrero")) {
                p = new Obrero(f[2], f[3], f[0]);
            } else {
                p = new DirectorObra(f[2], f[3], f[0]);
            }
            p.setFechaNacimiento(fecha(f[4]));
            p.setGenero(f[5]);
            p.setDireccion(f[6]);
            p.setTelefono(f[7]);
            p.setRol(Rol.valueOf(f[8]));
            p.setFechaIngreso(fecha(f[9]));
            if (f[10] != null) {
                p.setTipoVinculacion(TipoVinculacion.valueOf(f[10]));
            }
            int nivelRiesgo = f[13] == null ? 0 : Integer.parseInt(f[13]);
            p.setSeguridadSocial(new DatosSeguridadSocial(f[11], f[12], nivelRiesgo, f[14]));
            p.setContactoEmergencia(new ContactoEmergencia(f[15], f[16], f[17]));
            p.setDatosBancarios(new DatosBancarios(f[18], f[19], f[20]));
            personas.add(p);
        }

        // Cada fila trae: persona, tipo, tarifa
        for (String[] f : conexionBD.consultar("SELECT persona, tipo, tarifa FROM habilidades ORDER BY rowid")) {
            for (Persona p : personas) {
                if (p.getDocumentoIdentidad().equals(f[0])) {
                    p.agregarHabilidad(new Habilidad(TipoActividad.valueOf(f[1]), Double.parseDouble(f[2])));
                }
            }
        }
        return personas;
    }

    // Convierte el texto guardado en fecha (las fechas opcionales pueden venir vacías)
    private LocalDate fecha(String texto) {
        return texto == null ? null : LocalDate.parse(texto);
    }
}
